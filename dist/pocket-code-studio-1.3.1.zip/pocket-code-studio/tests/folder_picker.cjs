const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
const nodes = {}, pending = [];
function element() { return {setAttribute(){},value:'', disabled:false, children:[], listeners:{},
    addEventListener(type, fn){this.listeners[type]=fn;},
    replaceChildren(...children){this.children=children;}, append(...children){this.children.push(...children);},
    showModal(){this.open=true;},close(){this.open=false;this.listeners.close?.();}, focus(){},dispatchEvent(){},closest(){return {append(){}};}}; }
const get = id => nodes[id] ||= element();
get('settings-root').value='/srv/site'; get('destinationPath').value='/old';
const context = vm.createContext({document:{getElementById:get, createElement:element,createTextNode:text=>({text}),body:element()},
    SERVER_ROOT_PATH:'/srv/site',Event:class {},requestWorkspace:(action,fields)=>new Promise((resolve,reject)=>pending.push({action,fields,resolve,reject}))});
context.window ||= {}; context.window.workspaceLoading = (element, message) => { element.textContent = message; };
const start=source.indexOf("            const folderPicker = document.getElementById('folder-picker');");
vm.runInContext(source.slice(start,source.indexOf('            // ── File list',start)),context);
const flush=()=>new Promise(resolve=>setImmediate(resolve));
(async()=>{
    get('browse-destination').listeners.click();
    assert.equal(pending[0].fields.scope,'workspace');
    pending[0].resolve({folder:'/old',parent:'/',folders:[{name:'nested',path:'/old/nested',readable:true}]}); await flush();
    assert.equal(get('folder-picker-use').disabled,false);
    get('folder-picker-list').children[0].listeners.click();
    pending[1].resolve({folder:'/old/nested',parent:'/old',folders:[]});await flush();
    assert.equal(get('destinationPath').value,'/old');
    get('folder-picker-use').listeners.click();
    assert.equal(get('destinationPath').value,'/old/nested');
    get('browse-workspace').listeners.click();
    assert.equal(pending[2].fields.scope,'server');
    get('folder-picker-home').listeners.click();
    assert.equal(pending[3].fields.folder,'/srv/site');
    pending[3].resolve({folder:'/srv/site',parent:'/srv',folders:[]});await flush();
    pending[2].resolve({folder:'/stale',parent:'/',folders:[]});await flush();
    assert.equal(get('folder-picker-path').value,'/srv/site');
    get('folder-picker-cancel').listeners.click();
    assert.equal(get('settings-root').value,'/srv/site');
    console.log('PASS: destination selection, workspace scope, cancel, stale response protection and no changes before confirmation.');
})().catch(error=>{console.error(error);process.exitCode=1;});
