const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../filemanager.php'),'utf8');
const nodes={},requests=[],tabs=new Map();let response,failure;
function element(){return {children:[],style:{},listeners:{},value:'',disabled:false,checked:false,textContent:'',
 classList:{add(){}},setAttribute(){},addEventListener(type,fn){this.listeners[type]=fn;},append(...items){this.children.push(...items);},replaceChildren(...items){this.children=items;},
 querySelectorAll(){return [];},closest(){return get('details');}};}
const get=id=>nodes[id] ||= element();
get('github-settings').elements=Object.fromEntries(['url','branch','name','email','token','remove_token'].map(k=>[k,element()]));
const context=vm.createContext({document:{getElementById:get,createElement:element,querySelectorAll:selector=>get('github-files').children.flatMap(label=>label.children||[]).filter(node=>node.type==='checkbox'&&(selector.includes(':checked')?node.checked:!node.disabled))},
 editorTabs:tabs,gitStatusUnavailable:false,refreshGitStatus(){},window:{workspaceToast(){}},
 requestWorkspace:async(action,fields)=>{requests.push({action,fields});if(failure&&fields.operation!=='prepare')throw Error(failure);return response;}});
context.window ||= {}; context.window.workspaceLoading = (element, message) => { element.textContent = message; };
const start=source.indexOf('            function createGitStatusBadge(status, path = null)');
vm.runInContext(source.slice(start,source.indexOf('            const loginActivityModal =',start)),context);
response={settings:{has_token:true,url:'https://github.com/a/b.git'},repository:{branch:'main',head:'a'.repeat(40),revision:'preview',files:[{path:'<script>.txt',status:' M',allowed:true},{path:'symlink',status:'??',allowed:false}]}};
(async()=>{
 await context.githubOperation('read');
 assert.equal(get('github-settings').elements.branch.value,'main');
 assert.equal(get('github-settings').elements.token.value,'');
 const first=get('github-files').children[0];assert.equal(first.children[0].checked,false);
 assert.equal(first.children[2].textContent,'M');assert.equal(first.children[2].className,'git-status-badge');assert.equal(get('github-files').children[1].children[2].textContent,'U');
 for(const [raw,expected] of [['??','U'],[' M','M'],['A ','A'],[' D','D']]) assert.equal(context.createGitStatusBadge(raw).textContent,expected);
 assert.match(first.children[1].textContent,/<script>/);assert.equal(get('github-files').children[1].children[0].disabled,true);
 context.startGitHubPush(true);assert.equal(requests.length,1);assert.match(get('github-feedback').textContent,/Select files/);
 get('github-select-all').listeners.click();assert.equal(first.children[0].checked,true);assert.equal(get('github-files').children[1].children[0].checked,false);
 get('github-select-all').listeners.click();assert.equal(first.children[0].checked,true);
 first.children[0].checked=true;get('github-message').value='My commit';
 tabs.set('dirty',{dirty:true});context.startGitHubPush(true);assert.equal(requests.length,1);assert.match(get('github-feedback').textContent,/Save or close/);
 tabs.clear();failure='Push failed';context.startGitHubPush(true);await new Promise(setImmediate);
 assert.equal(requests.at(-1).fields.operation,'commit_push');assert.equal(requests.at(-1).fields.head,'a'.repeat(40));assert.equal(JSON.parse(requests.at(-1).fields.preview).length,1);
 assert.deepEqual(JSON.parse(requests.at(-1).fields.files),['<script>.txt']);assert.match(get('github-feedback').textContent,/Push existing commits/);
 const count=requests.length;context.startGitHubPush(false);assert.equal(requests.length,count);assert.match(get('github-feedback').textContent,/Refresh/);
 failure=null;await context.githubOperation('read');tabs.set('dirty',{dirty:true});context.startGitHubPush(false);await new Promise(setImmediate);
 assert.equal(requests.at(-1).fields.operation,'push');assert.equal(requests.at(-1).fields.head,'a'.repeat(40));assert.equal(requests.at(-1).fields.branch,'main');
 console.log('PASS: GitHub file selection, literal paths, unsupported files, dirty guard, preview revision and explicit push retry.');
})().catch(error=>{console.error(error);process.exitCode=1;});
