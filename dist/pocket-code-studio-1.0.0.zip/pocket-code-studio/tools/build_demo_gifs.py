"""Build GitHub-friendly GIFs from real UI screenshots captured with Computer Use.
Usage: python3 tools/build_demo_gifs.py /path/to/frames
Requires Pillow. Input PNGs include Chrome chrome; crop bounds are specific to this recording.
"""
from pathlib import Path
import argparse
from PIL import Image, ImageDraw, ImageFont, ImageOps

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('frames',type=Path)
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'screenshots')
args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
width=1280
font_path=Path('/System/Library/Fonts/Supplemental/Arial.ttf')
bold_path=Path('/System/Library/Fonts/Supplemental/Arial Bold.ttf')
def font(size,bold=False):
    path=bold_path if bold else font_path
    return ImageFont.truetype(str(path),size) if path.exists() else ImageFont.load_default()

def frame(name,title,description):
    shot=Image.open(args.frames/name).convert('RGB')
    # Strip ALL browser tabs, address bar and bookmarks. Only our demo application remains.
    shot=shot.crop((0,242,shot.width,shot.height))
    shot=shot.resize((width,round(shot.height*width/shot.width)),Image.Resampling.LANCZOS)
    canvas=Image.new('RGB',(width,shot.height+76),'#10141c');draw=ImageDraw.Draw(canvas)
    draw.text((22,14),title,fill='#e2e8f0',font=font(22,True))
    draw.text((22,44),description,fill='#9da5b4',font=font(14))
    brand='POCKET CODE STUDIO';box=draw.textbbox((0,0),brand,font=font(12,True))
    draw.text((width-22-(box[2]-box[0]),22),brand,fill='#7aa2f7',font=font(12,True))
    canvas.paste(shot,(0,76));return canvas

sequences=[
 ('workspace-tabs.gif','A workspace that stays with you','Open PHP, CSS and templates in separate tabs.',
  [('tabs-01.png',1500),('tabs-02.png',1600),('tabs-03.png',1600),('tabs-04.png',2000)]),
 ('edit-and-save.gif','Edit. Save. Verified.','Syntax highlighting, unsaved indicators and a verified-save notification.',
  [('edit-01.png',1700),('edit-02.png',1500),('edit-03.png',1500),('edit-04.png',2600)]),
 ('git-diff.gif','See exactly what changed','Compare with Git HEAD, including unsaved edits, with old and new line numbers.',
  [('theme-02.png',1300),('git-01.png',1300),('git-02.png',2800),('git-03.png',2300)]),
]
for name,title,description,items in sequences:
    rgb=[frame(file,title,description) for file,_ in items]
    # One shared palette avoids flickering colors between frames.
    contact=Image.new('RGB',(width,rgb[0].height*len(rgb)))
    for i,image in enumerate(rgb):contact.paste(image,(0,rgb[0].height*i))
    palette=contact.quantize(colors=256,method=Image.Quantize.MEDIANCUT)
    indexed=[image.quantize(palette=palette,dither=Image.Dither.NONE) for image in rgb]
    path=args.output/name
    indexed[0].save(path,save_all=True,append_images=indexed[1:],duration=[duration for _,duration in items],loop=0,optimize=True,disposal=1)
    with Image.open(path) as check:
        assert check.n_frames==len(items) and check.size==rgb[0].size
        assert check.info.get('loop')==0
    print(f'{name}: {path.stat().st_size/1024:.0f} KiB, {len(items)} frames, {sum(t for _,t in items)/1000:.1f}s')
# Static previews are useful in GitHub issues, social posts and release notes.
frame('edit-04.png','Pocket Code Studio','A single-file PHP workspace with tabs, themes and verified saves.').save(args.output/'editor-preview.png',optimize=True)
frame('git-02.png','Git changes, at a glance','Compare the current editor with HEAD.').save(args.output/'git-diff-preview.png',optimize=True)
