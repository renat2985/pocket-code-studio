"""HTTP upload checks use temporary fixtures and never touch project files."""
import hashlib,json,os,re,shutil,socket,subprocess,tempfile,time,urllib.request,urllib.error,uuid
from pathlib import Path
helpers=Path(__file__).with_name('authentication.py').read_text().split("with tempfile.TemporaryDirectory(prefix='fm-auth-tests-')")[0]
namespace={'__file__':str(Path(__file__).with_name('authentication.py'))};exec(helpers,namespace)
Client=namespace['Client'];PASSWORD=namespace['PASSWORD'];SOURCE=namespace['SOURCE'];test_hash=namespace['test_hash']
with tempfile.TemporaryDirectory(prefix='pcs-uploads-') as temporary:
    root=Path(temporary).resolve();target=root/'filemanager.php'
    target.write_text(re.sub(r"^\$authPasswordHash = '[^']*';$","$authPasswordHash = '"+test_hash(PASSWORD)+"';",SOURCE.read_text(),flags=re.M))
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    server=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        client=Client(f'http://127.0.0.1:{port}/filemanager.php')
        for _ in range(100):
            try:client.request();break
            except OSError:time.sleep(.03)
        status,body,_=client.login();assert status==200
        client.csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',body)[1].decode()
        def check(files,folder=''):
            status,body,_=client.request(fields={'action':'upload_check','path':folder,'files':json.dumps([{'name':name,'size':len(data)} for name,data in files])})
            return status,json.loads(body)
        def upload(files,manifest=None,folder=''):
            boundary='pcs-'+uuid.uuid4().hex;parts=[]
            fields={'path':folder}
            if manifest is not None:fields['upload_manifest']=json.dumps(manifest)
            for key,value in fields.items():parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
            for name,data in files:
                parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="files[]"; filename="{name}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+data+b'\r\n')
            parts.append(f'--{boundary}--\r\n'.encode())
            req=urllib.request.Request(client.url,data=b''.join(parts),headers={'Content-Type':'multipart/form-data; boundary='+boundary,'X-FM-CSRF':client.csrf})
            try:
                with client.opener.open(req) as response:return response.status,json.loads(response.read())
            except urllib.error.HTTPError as error:return error.code,json.loads(error.read())
        assert upload([('new.txt',b'new')])[0]==400 and not (root/'new.txt').exists()
        status,data=check([('new.txt',b'new')]);assert status==200 and data['files']=={'new.txt':None}
        status,result=upload([('new.txt',b'new')],data['files']);assert status==200 and result['uploaded']==['new.txt'],result
        assert (root/'new.txt').read_bytes()==b'new' and (root/'new.txt').stat().st_mode&0o444
        (root/'new.txt').chmod(0o640)
        assert upload([('new.txt',b'overwrite')],{'new.txt':None})[0]==400
        assert (root/'new.txt').read_bytes()==b'new'
        status,data=check([('new.txt',b'replaced')]);assert data['files']['new.txt']==hashlib.sha256(b'new').hexdigest()
        status,result=upload([('new.txt',b'replaced')],data['files']);assert status==200,result
        assert (root/'new.txt').read_bytes()==b'replaced' and (root/'new.txt').stat().st_mode&0o777==0o640
        stale=check([('new.txt',b'old-request')])[1]['files'];(root/'new.txt').write_bytes(b'external')
        status,result=upload([('new.txt',b'old-request')],stale);assert status==400 and result['status']=='error'
        assert (root/'new.txt').read_bytes()==b'external' and result['failedFiles']
        # Honest partial response; files that appeared after confirmation stay intact.
        (root/'collision.txt').write_bytes(b'keep')
        status,result=upload([('ok.txt',b'ok'),('collision.txt',b'bad')],{'ok.txt':None,'collision.txt':None})
        assert status==200 and result['status']=='partial' and result['uploaded']==['ok.txt']
        assert (root/'collision.txt').read_bytes()==b'keep' and (root/'ok.txt').read_bytes()==b'ok'
        (root/'link.txt').symlink_to(root/'new.txt')
        assert check([('link.txt',b'x')])[0]==400
        assert check([('../escape.txt',b'x')])[0]==400
        assert check([('a.txt',b'a'),('a.txt',b'b')])[0]==400
        (root/'hard.txt').hardlink_to(root/'new.txt')
        data=check([('hard.txt',b'unsafe')])[1]
        assert upload([('hard.txt',b'unsafe')],data['files'])[0]==400
        assert (root/'new.txt').read_bytes()==b'external'
        data=check([('missing.txt',b'')])[1]
        status,result=upload([],data['files'])
        # No multipart files means no upload handler; no false success should be returned.
        assert status>=400 or result.get('status')!='success'
        assert not list(root.glob('.fm-upload-*'))
        print('PASS: upload preflight, explicit replacement, verified bytes/modes, stale conflicts, honest partial errors, symlink/traversal/hard-link guards and staging cleanup.')
    finally:
        server.terminate();server.wait()
        tmp=Path(subprocess.check_output(['php','-r','echo sys_get_temp_dir();']).decode())
        for prefix,key in [('fm-editor-',str(target)+'|'+str(root)),('fm-auth-',str(target))]:
            directory=tmp/(prefix+hashlib.sha256(key.encode()).hexdigest()[:24])
            if directory.is_dir() and not directory.is_symlink():shutil.rmtree(directory)
