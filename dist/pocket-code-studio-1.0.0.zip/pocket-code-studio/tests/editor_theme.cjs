const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../filemanager.php'),'utf8');
const values=new Map(),modules={},pending={},vars={},frames=[],errors=[];
const root={dataset:{},style:{setProperty:(k,v)=>vars[k]=v}};
function node(){return {className:'',style:{},append(child){child.parent=this;if(child.src)pending[child.src]=child;},remove(){},};}
const document={documentElement:root,body:node(),head:node(),getElementById:()=>null,querySelectorAll:()=>frames,addEventListener:()=>{},createElement:node};
const importedStyles=new Set();
modules['ace/lib/dom']={importCssString:(css,id,target)=>{assert.equal(target,document);importedStyles.add(id);}};
const window={ace:{require:id=>modules[id]},workspaceAlert:(...args)=>errors.push(args)};
const localStorage={getItem:k=>values.get(k),setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};
function getComputedStyle(el){
 let parent=el;while(parent.parent && !parent.className.includes("ace_editor"))parent=parent.parent;
 assert(importedStyles.has(parent.className.replace('ace_editor ','')),'theme CSS must be explicitly inserted before color extraction, even without an editor');
 const light=parent.className.includes('light');
 const bg=light?'rgb(255,255,255)':'rgb(32,34,40)',fg=light?'rgb(30,32,36)':'rgb(220,225,230)';
 return {backgroundColor:bg,color:el.className.includes('function')?'rgb(60,130,210)':el.className.includes('comment')?'rgb(120,120,120)':fg};
}
const context=vm.createContext({window,document,ace:window.ace,localStorage,getComputedStyle,setTimeout,clearTimeout,console,Option:function(){}});
const start=source.indexOf('    const editorThemes = ');
vm.runInContext(source.slice(start,source.indexOf('    function escapeAlertText',start)),context);
assert.equal(window.editorThemeNames.length,43);assert.equal(window.getEditorTheme(),'one_dark');
values.set('ke_theme','tokyo_night');assert.equal(window.getEditorTheme(),'one_dark');
values.set('ke_theme','cobalt');assert.equal(window.getEditorTheme(),'cobalt');
values.set('ke_editor_theme','dawn');assert.equal(window.getEditorTheme(),'dawn');
modules['ace/theme/dawn']={cssClass:'light',isDark:false};modules['ace/theme/monokai']={cssClass:'dark',isDark:true};
let editorTheme,frameTheme;
window.applySelectedTheme=t=>editorTheme=t;
frames.push({contentWindow:{setWorkspaceTheme:(t,persist)=>{frameTheme=t;assert.equal(persist,false);}}});
(async()=>{
 await window.setWorkspaceTheme('dawn');assert.equal(root.style.colorScheme,'light');assert.equal(editorTheme,'dawn');assert.equal(frameTheme,'dawn');assert.equal(values.has('ke_editor_theme'),false);
 assert.equal(vars['--bg-deep'],'rgb(255,255,255)');assert.equal(vars['--danger-contrast'],'#fff');
 await window.setWorkspaceTheme('monokai');assert.equal(root.style.colorScheme,'dark');assert.equal(vars['--bg-deep'],'rgb(32,34,40)');
 assert(Object.values(vars).every(v=>!v.includes('NaN')));
 const url=t=>'https://cdn.jsdelivr.net/npm/ace-builds@1.45.2/src-min-noconflict/theme-'+t+'.js';
 const old=window.setWorkspaceTheme('twilight');await window.setWorkspaceTheme('dawn');
 modules['ace/theme/twilight']={cssClass:'dark',isDark:true};pending[url('twilight')].onload();await old;assert.equal(editorTheme,'dawn','late theme must not overwrite newer choice');
 const failed=window.setWorkspaceTheme('chaos');pending[url('chaos')].onerror();await failed;
 assert.equal(editorTheme,'dawn');assert.equal(errors.length,1);assert.equal(values.get('ke_theme'),'dawn');
 const retry=window.setWorkspaceTheme('chaos');modules['ace/theme/chaos']={cssClass:'dark',isDark:true};pending[url('chaos')].onload();await retry;assert.equal(editorTheme,'chaos');
 assert(!source.includes('ace/theme/theme_mix'));assert(!source.includes('id="editor-theme"'));
 console.log('PASS: unified Ace palettes, migration, light/dark colors, all-tab updates, CDN failure/retry and stale loads.');
})().catch(e=>{console.error(e);process.exitCode=1;});

// The loading mask must survive both DOM readiness and the asynchronous theme callback.
{
 const overlay={style:{display:'flex'}},frame={dataset:{loading:'true'},style:{visibility:'hidden'}};
 const revealWindow={frameElement:frame};let themeCallback,paint;
 const readyContext=vm.createContext({window:revealWindow,document:{getElementById:()=>overlay},
 editor:{setTheme:(_,callback)=>themeCallback=callback},requestAnimationFrame:fn=>paint=fn,
 inlineDiffView:null,mapColors:{clear(){}},scheduleMinimap(){}});
 let a=source.indexOf('        window.finishEditorLoading = function()');
 vm.runInContext(source.slice(a,source.indexOf('        // ── Ace Editor',a)),readyContext);
 a=source.indexOf('        window.applySelectedTheme = function(theme)');
 vm.runInContext(source.slice(a,source.indexOf('        function changeMode',a)),readyContext);
 revealWindow.applySelectedTheme('monokai');assert.equal(overlay.style.display,'flex');
 themeCallback();assert.equal(overlay.style.display,'flex','wait for the themed paint');
 paint();assert.equal(overlay.style.display,'none');assert.equal(frame.style.visibility,'');assert.equal(frame.dataset.loading,undefined);
 console.log('PASS: editor is revealed only after its theme is ready to paint.');
}
