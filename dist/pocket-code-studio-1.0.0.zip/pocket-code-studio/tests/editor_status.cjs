const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
function run(content) {
    const nodes = {};
    const node = id => nodes[id] ||= {value:'', dataset:{}, addEventListener(type, fn) { if (type !== 'close') this[type] = fn; },
        showModal() {this.open=true;}, close() {this.open=false;}, select(){}};
    const settings = {};
    const editor = {session: {getLength: () => 20, setTabSize: value => settings.size=value, setUseSoftTabs: value => settings.soft=value},
        getCursorPosition: () => ({row: 6}), focus(){}, gotoLine: line => settings.line=line};
    const context = vm.createContext({document:{getElementById:node}, editor, originalContent:content, savingFile:false, hasUnsavedChanges:false});
    const start = source.indexOf("        const gotoDialog = document.getElementById('goto-dialog');");
    vm.runInContext(source.slice(start, source.indexOf('        // ── Theme / Mode / Font', start)), context);
    assert.equal(settings.soft, !content.startsWith('\t'));
    node('status-cursor').click(); assert.equal(node('goto-line').value, 7); assert.equal(node('goto-line').max, 20);
    node('goto-line').value=12; node('goto-form').submit({preventDefault(){},currentTarget:{reportValidity:()=>true}});
    assert.equal(settings.line,12); assert.equal(node('goto-dialog').open,false);
    context.updateSaveStatus(); assert.equal(node('status-saved').textContent,'Saved');
    context.hasUnsavedChanges=true; context.updateSaveStatus(); assert.equal(node('status-saved').textContent,'Unsaved');
    context.savingFile=true; context.updateSaveStatus(); assert.equal(node('status-saved').textContent,'Saving…');
    context.savingFile=false; context.hasUnsavedChanges=false;
    vm.runInContext('lastSavedAt = new Date(2026,0,1,14,32,5); updateSaveStatus()', context);
    assert.equal(node('status-saved').textContent,'Saved 14:32:05');
    node('indentation').value='spaces:2'; node('indentation').change(); assert.equal(settings.size,2); assert.equal(settings.soft,true);
}
run('    example\n        nested'); run('\tindented\n\t\tnested'); run('');
console.log('PASS: go-to-line, indentation detection/settings, unsaved/saving/saved timestamp.');
