"""Exercise actual trash helpers on disposable files; never touch the workspace trash."""
from pathlib import Path
import subprocess,tempfile
source=Path(__file__).resolve().parents[1].joinpath('filemanager.php').read_text()
delete=source[source.index('function deleteItem($path)'):source.index('function copyItem(',source.index('function deleteItem($path)'))]
trash=source[source.index('function fmCleanupTrashMetadata('):source.index('function extractArchive(',source.index('function fmCleanupTrashMetadata('))]
checks=r'''
function check($ok, $message) { if (!$ok) throw new RuntimeException($message); }
$root = $argv[1]; $config=['root_path'=>$root]; mkdir($root.'/original');
file_put_contents($root.'/original/one.txt','one');
check(moveToTrash($root.'/original/one.txt',$root.'/original',$config),'trash move');
$trash=$root.'/.trash';
check(is_file($trash.'/one.txt.trashinfo'),'metadata created');
check(fmCleanupTrashMetadata($config)===0 && is_file($trash.'/one.txt.trashinfo'),'live metadata retained');
check(deleteItem($trash.'/one.txt'),'delete trashed file');
check(fmCleanupTrashMetadata($config)===0 && !file_exists($trash.'/one.txt.trashinfo'),'metadata removed after permanent delete');
file_put_contents($root.'/original/two.txt','two'); moveToTrash($root.'/original/two.txt',$root.'/original',$config);
unlink($trash.'/two.txt');
check(fmCleanupTrashMetadata($config)===0 && count(array_diff(scandir($trash),['.','..']))===0,'legacy orphan removed from otherwise empty trash');
file_put_contents($root.'/original/restore.txt','restore'); moveToTrash($root.'/original/restore.txt',$root.'/original',$config);
check(restoreFromTrash($trash.'/restore.txt',$config)['status']==='success','restore');
check(file_get_contents($root.'/original/restore.txt')==='restore' && !file_exists($trash.'/restore.txt.trashinfo'),'restore metadata cleanup');
// User files with the same suffix and non-metadata contents must survive cleanup.
file_put_contents($trash.'/notes.trashinfo','user document');
check(fmCleanupTrashMetadata($config)===0 && is_file($trash.'/notes.trashinfo'),'ordinary suffixed file retained');
mkdir($root.'/original/folder'); file_put_contents($root.'/original/folder/a.txt','a');
mkdir($root.'/outside');file_put_contents($root.'/outside/keep.txt','keep');
symlink($root.'/outside',$root.'/original/folder/link');
check(moveToTrash($root.'/original/folder',$root.'/original',$config),'folder trash');
check(deleteItem($trash.'/folder'),'recursive permanent delete');
check(fmCleanupTrashMetadata($config)===0 && !file_exists($trash.'/folder.trashinfo'),'folder metadata cleanup');
check(file_get_contents($root.'/outside/keep.txt')==='keep','directory symlink target survives');
// A dangling symlink is still an existing trash item: retain its metadata.
symlink($root.'/missing',$trash.'/dangling');
file_put_contents($trash.'/dangling.trashinfo',json_encode(['original_name'=>'dangling','original_path'=>'/dangling','deletion_date'=>'2026-10-24']));
fmCleanupTrashMetadata($config);check(is_file($trash.'/dangling.trashinfo'),'dangling link metadata retained');
// Never clean an external directory reached through .trash itself being a symlink.
mkdir($root.'/other');file_put_contents($root.'/outside/orphan.trashinfo',json_encode(['original_name'=>'orphan','original_path'=>'/orphan','deletion_date'=>'2026-10-24']));
symlink($root.'/outside',$root.'/other/.trash');
fmCleanupTrashMetadata(['root_path'=>$root.'/other']);check(is_file($root.'/outside/orphan.trashinfo'),'external trash symlink untouched');
echo "PASS: trash sidecars, legacy orphan cleanup, restore, folder deletion, ordinary .trashinfo files and symlink safety.\n";
'''
with tempfile.TemporaryDirectory(prefix='fm-trash-tests-') as folder:
    root=Path(folder);script=root/'test.php';workspace=root/'workspace';workspace.mkdir()
    script.write_text('<?php\n'+delete+trash+checks)
    subprocess.run(['php',str(script),str(workspace)],check=True)
