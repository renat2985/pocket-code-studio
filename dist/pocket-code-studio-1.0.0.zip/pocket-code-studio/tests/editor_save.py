"""Byte-for-byte regression checks for the editor's HTTP save endpoint."""
import base64, http.cookiejar, concurrent.futures, hashlib, json, os, re, shutil, socket, subprocess, tempfile, time, urllib.request, urllib.error
from pathlib import Path
SOURCE = Path(__file__).resolve().parents[1] / 'filemanager.php'
def digest(data): return hashlib.sha256(data).hexdigest()
with tempfile.TemporaryDirectory(prefix='fm-save-tests-') as folder:
    root = Path(folder)
    test_password='Editor-save-test-password'
    password_hash=subprocess.check_output(['php','-r','echo password_hash($argv[1], PASSWORD_BCRYPT, ["cost"=>4]);',test_password]).decode()
    source=re.sub(r"^\$authPasswordHash = '[^']*';$", "$authPasswordHash = '"+password_hash+"';", SOURCE.read_text(), flags=re.M)
    (root/'filemanager.php').write_text(source)
    client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    csrf=None
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
    proc=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    base=f'http://127.0.0.1:{port}/filemanager.php?editor=1&filename='
    def url(path): return base+urllib.parse.quote(str(path),safe='')
    def request(path,payload=None,check=False):
        req=urllib.request.Request(url(path)+('&check=1' if check else ''),data=None if payload is None else json.dumps(payload).encode(),headers={'Content-Type':'application/json', 'X-FM-CSRF':csrf or ''})
        try:
            with client.open(req,timeout=8) as response:return response.status,response.read()
        except urllib.error.HTTPError as error:return error.code,error.read()
    def save(path,old,new,**changes):
        payload={'base_hash':digest(old),'content_base64':base64.b64encode(new).decode(),'byte_length':len(new)}
        payload.update(changes)
        status,body=request(path,payload)
        return status,json.loads(body)
    try:
        for _ in range(100):
            try: urllib.request.urlopen(f'http://127.0.0.1:{port}',timeout=.2);break
            except (OSError,urllib.error.HTTPError):time.sleep(.03)
        login_url=f'http://127.0.0.1:{port}/filemanager.php'
        try:client.open(login_url)
        except urllib.error.HTTPError as response:login_html=response.read()
        csrf=re.search(rb'name="fm_csrf" value="([a-f0-9]+)"',login_html)[1].decode()
        login=client.open(urllib.request.Request(login_url,data=urllib.parse.urlencode({'fm_auth_action':'login','password':test_password,'fm_csrf':csrf}).encode()))
        csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',login.read())[1].decode()
        text='Привет 🙂 <>& "quotes" \'single\' </script> &lt; literal\n'.encode()
        for label,old,new in [
            ('utf8-lf',text,text+b'next\n'),
            ('crlf',b'line1\r\nline2\r\n',b'line1\r\nchanged\r\n'),
            ('bom',b'\xef\xbb\xbf'+text,b'\xef\xbb\xbf'+text+b'next\n'),
            ('no-final-newline',b'initial',b'changed'),
            ('empty',b'',b'new text'),
            ('empty-save',b'initial',b''),
            ('large',b'line\n'*100000,b'line\n'*100001),
        ]:
            path=root/(label+'.txt');path.write_bytes(old);os.chmod(path,0o640)
            if old:
                status,html=request(path)
                initial=re.search(rb'const originalContent = (.*?);\n',html).group(1)
                assert json.loads(initial).encode('utf-8')==old,(label,'load changed bytes')
                assert b'<div id="editor"></div>' in html
            before=path.stat().st_mtime_ns
            status,data=save(path,old,old)
            assert status==200 and not data['backup_created'] and path.read_bytes()==old and path.stat().st_mtime_ns==before,(label,data)
            status,data=save(path,old,new)
            assert status==200 and data['hash']==digest(new) and data['byte_length']==len(new) and path.read_bytes()==new,(label,data)
            assert path.stat().st_mode&0o777==0o640
            status,data=save(path,old,b'stale text')
            assert status==409 and path.read_bytes()==new,(label,data)
        path=root/'invalid.txt';old=b'original\n';path.write_bytes(old)
        for change in [{'byte_length':0},{'content_base64':'***'},{'base_hash':'invalid'}]:
            status,data=save(path,old,b'changed\n',**change)
            assert status>=400 and path.read_bytes()==old
        status,body=request(path,{})
        assert status==400 and path.read_bytes()==old
        for label,content in [('binary',b'abc\0def'),('non-utf8',b'\xff\xfe')]:
            path=root/(label+'.dat');path.write_bytes(content)
            status,data=save(path,content,content)
            assert status>=400 and path.read_bytes()==content
            status,page=request(path)
            assert status==400 and b'var editor = ace.edit' not in page
            assert b'window.fmEditorOpenError=' in page and page.rstrip().endswith(b'</html>')
            assert b'window.workspaceAlert(window.fmEditorOpenError' in page
            status,checked=request(path,check=True)
            assert status==400 and json.loads(checked)['status']=='error'
        for label,old in [('mixed-crlf',b'a\r\nb\n'),('mixed-cr',b'a\rb\n'),('mixed-all',b'a\r\nb\rc\n'),('mixed-bom',b'\xef\xbb\xbfa\r\nb\n')]:
            path=root/(label+'.txt');path.write_bytes(old)
            status,page=request(path);assert status==200 and b'let mixedLineEndings = true' in page and b'Mixed line endings' in page
            status,checked=request(path,check=True);assert status==200 and json.loads(checked)['kind']=='text'
            status,data=save(path,old,old);assert status==200 and not data['backup_created'] and path.read_bytes()==old
            new=old.replace(b'\r\n',b'\n').replace(b'\r',b'\n')+b'edited\n'
            status,data=save(path,old,new);assert status==200 and data['backup_created'] and path.read_bytes()==new
            path.write_bytes(old);assert save(path,old,b'changed\r\ntext\n')[0]>=400 and path.read_bytes()==old
        path=root/'bom-preserve.txt';old=b'\xef\xbb\xbfhello\n';path.write_bytes(old)
        assert save(path,old,b'hello\n')[0]>=400 and path.read_bytes()==old
        path=root/'endings-preserve.txt';old=b'hello\r\n';path.write_bytes(old)
        assert save(path,old,b'hello\n')[0]>=400 and path.read_bytes()==old
        path=root/'readonly.txt';path.write_bytes(b'old');os.chmod(path,0o440)
        assert save(path,b'old',b'new')[0]>=400 and path.read_bytes()==b'old'
        blocked=root/'blocked';blocked.mkdir();path=blocked/'file.txt';path.write_bytes(b'old');os.chmod(blocked,0o500)
        try:assert save(path,b'old',b'new')[0]>=400 and path.read_bytes()==b'old'
        finally:os.chmod(blocked,0o700)
        path=root/'linked.txt';path.write_bytes(b'old');os.link(path,root/'linked-alias.txt')
        assert save(path,b'old',b'new')[0]>=400 and path.read_bytes()==b'old'
        path=root/'concurrent.txt';path.write_bytes(b'old')
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            results=list(pool.map(lambda new:save(path,b'old',new)[0],[b'first',b'second']))
        assert sorted(results)==[200,409] and path.read_bytes() in [b'first',b'second']
        php_temp,php_script,php_root=json.loads(subprocess.check_output(['php','-r','echo json_encode([sys_get_temp_dir(),realpath($argv[1]),realpath($argv[2])]);',str(root/'filemanager.php'),str(root)]))
        backupdir=Path(php_temp)/('fm-editor-'+digest((php_script+'|'+php_root).encode())[:24])
        backups=list(backupdir.glob('*.bak'))
        assert any(f.read_bytes()==text for f in backups)
        assert all(f.stat().st_mode&0o777==0o600 for f in backups)
        assert backupdir.stat().st_mode&0o777==0o700
        shutil.rmtree(backupdir)
        authdir=Path(php_temp)/('fm-auth-'+digest(php_script.encode())[:24]);shutil.rmtree(authdir)
        assert not list(root.rglob('.fm-save-*'))
        print('PASS: UTF-8, emoji, HTML literals, LF/CRLF, BOM, empty/large files, no-op bytes, conflicts, malformed requests, encoding guards, write failure, permissions, hard links, concurrency, verified backups, temporary-file cleanup.')
    finally:
        proc.terminate();proc.wait(timeout=5)
