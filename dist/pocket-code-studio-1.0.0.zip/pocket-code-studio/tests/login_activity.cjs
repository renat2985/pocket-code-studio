const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../filemanager.php'),'utf8');
const nodes={},requests=[];
function element(){return {children:[],style:{},dataset:{},listeners:{},hidden:false,textContent:'',
    addEventListener(type,fn){this.listeners[type]=fn;},replaceChildren(...items){this.children=items;},append(...items){this.children.push(...items);},
    querySelectorAll(selector){const all=[];function visit(node){if(selector==='[data-login-until]'&&node.dataset?.loginUntil)all.push(node);for(const child of node.children||[])visit(child);}visit(this);return all;}};}
const get=id=>nodes[id] ||= element();
get('login-policy-form').elements={per_ip:{},global:{},window_minutes:{}};
get('login-policy-form').reportValidity=()=>true;
get('loginActivityModal').children=[get('login-activity-rows')];
let data;const now=Math.floor(Date.now()/1000);
const context=vm.createContext({document:{getElementById:get,createElement:element},setInterval:()=>1,clearInterval(){},
    requestWorkspace:async(action,fields)=>{requests.push({action,fields});return data;}});
const start=source.indexOf("            const loginActivityModal = document.getElementById('loginActivityModal');");
vm.runInContext(source.slice(start,source.indexOf('            const folderPicker =',start)),context);
data={now,current_ip:'127.0.0.1',last_success:now,failures_24h:2,blocked_ips:1,global_blocked_until:null,
    policy:{per_ip:8,global:64,window_minutes:15},rows:[{key:'a'.repeat(64),ip:'203.0.113.10',first:now-50,last:now,failures:2,attempts:8,blocked_until:now+100,last_success:null,
        agent:'<img src=x onerror=alert(1)>',events:[{last:now,result:'blocked',count:4}]}]};
(async()=>{
    context.renderLoginActivity(data);
    assert.match(get('login-activity-summary').textContent,/Blocked IPs: 1/);
    const row=get('login-activity-rows').children[0];assert.equal(row.children[0].textContent,'203.0.113.10');
    assert.match(row.children[3].children[0].textContent,/Blocked · 2 min/);
    row.listeners.click();assert.equal(get('login-activity-details').hidden,false);
    assert.ok(get('login-activity-details').children.some(node=>node.textContent.includes('<img src=x')));
    const reset=row.children[4].children[0];reset.listeners.click({stopPropagation(){}});await new Promise(resolve=>setImmediate(resolve));
    assert.equal(requests[0].fields.operation,'reset');assert.equal(requests[0].fields.key,'a'.repeat(64));
    get('login-policy-form').listeners.submit({preventDefault(){}});await new Promise(resolve=>setImmediate(resolve));
    assert.equal(requests.at(-1).fields.operation,'policy');assert.equal(requests.at(-1).fields.window_minutes,15);
    data.global_blocked_until=now+60;data.rows[0].blocked_until=null;context.renderLoginActivity(data);
    assert.equal(get('login-global-limit').hidden,false);
    assert.match(get('login-activity-rows').children[0].children[3].children[0].textContent,/Global block/);
    console.log('PASS: login summary/details, literal browser text, countdown, reset/policy requests and global-block state.');
})().catch(error=>{console.error(error);process.exitCode=1;});
