const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
const start = source.indexOf('            function tabHasChanges(');
const end = source.indexOf("            ['renameModal'", start);
const tabs = new Map();
let activated, refreshed = 0, saved = 0;
const context = vm.createContext({editorTabs: tabs, activeEditorPath: '/b',
    activateTab: path => { activated = path; context.activeEditorPath = path; },
    refreshMobileTabs: () => refreshed++, scheduleSaveTabs: () => saved++});
vm.runInContext(source.slice(start, end), context);
function tab(content = {}) {
    return {dirty: false, frame: {contentWindow: content, remove() { this.removed = true; }},
        element: {remove() { this.removed = true; }}};
}
const a = tab({editor: {}}), b = tab({fmImagePreview: true}), c = tab();
tabs.set('/a', a); tabs.set('/b', b); tabs.set('/c', c);
assert.equal(context.tabCanManageFile(a), true);
assert.equal(context.tabCanManageFile(b), true);
assert.equal(context.tabCanManageFile(c), false);
assert.equal(context.tabCanManageFile(undefined), false);
assert.equal(context.tabHasChanges(a), false);
a.frame.contentWindow.hasUnsavedChanges = true;
assert.equal(context.tabHasChanges(a), true);
a.frame.contentWindow.hasUnsavedChanges = false; a.dirty = true;
assert.equal(context.tabHasChanges(a), true);
// A late callback for an old tab must not close a newly opened tab at the same path.
context.removeEditorTab('/b', tab(), true);
assert.equal(tabs.get('/b'), b);
assert.equal(saved, 0);
context.removeEditorTab('/b', b, true);
assert.equal(tabs.has('/b'), false);
assert.equal(activated, '/a');
assert.equal(b.frame.removed && b.element.removed, true);
assert.equal(refreshed, 1); assert.equal(saved, 1);
// Removing a background tab must preserve the active tab.
context.removeEditorTab('/c', c);
assert.equal(context.activeEditorPath, '/a');
context.removeEditorTab('/a', a);
assert.equal(activated, null);
assert.equal(tabs.size, 0);
console.log('PASS: text/image capabilities, unsaved guards, neighbor activation, stale removal, background removal.');
