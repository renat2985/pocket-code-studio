const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../filemanager.php'),'utf8');
const calls=[];
const ctx={drawImage:(...args)=>calls.push(['image',...args]),beginPath(){},arc:(...args)=>calls.push(['dot',...args]),fill(){},stroke(){}};
class FakeImage {
    naturalWidth=32;naturalHeight=16;
    set src(url){this.url=url;queueMicrotask(()=>url.includes('missing')?this.onerror():this.onload());}
}
const context=vm.createContext({Image:FakeImage,setTimeout,clearTimeout,location:{hostname:'example.com'},
    document:{createElement:()=>({getContext:()=>ctx,toDataURL:()=> 'data:image/png;base64,site-with-dot'})}});
const start=source.indexOf('    function badgeSiteIcon('),end=source.indexOf('    async function loadSiteIcon(',start);
vm.runInContext(source.slice(start,end),context);
(async()=>{
    assert.equal(await context.badgeSiteIcon('https://example.com/icon.png'),'data:image/png;base64,site-with-dot');
    assert.deepEqual(calls[0].slice(2),[0,16,64,32]);
    assert.deepEqual(calls[1].slice(1,4),[51,51,11]);
    assert.match(ctx.fillStyle,/^hsl\(\d+,75%,50%\)$/);
    assert.equal(ctx.strokeStyle,'#ffffff');
    await assert.rejects(context.badgeSiteIcon('https://example.com/missing.ico'));
    console.log('PASS: original favicon aspect ratio, domain-colored dot, white outline and failed-icon fallback signal.');
})().catch(error=>{console.error(error);process.exitCode=1;});
