"""Login activity, limits and post-login notices; temporary installation only."""
import hashlib,json,re,shutil,socket,subprocess,tempfile,time
from pathlib import Path
helpers=Path(__file__).with_name('authentication.py').read_text().split("with tempfile.TemporaryDirectory(prefix='fm-auth-tests-')")[0]
namespace={'__file__':str(Path(__file__).with_name('authentication.py'))};exec(helpers,namespace)
Client=namespace['Client'];SOURCE=namespace['SOURCE'];PASSWORD=namespace['PASSWORD'];test_hash=namespace['test_hash']
with tempfile.TemporaryDirectory(prefix='pcs-login-activity-') as temporary:
    root=Path(temporary).resolve();target=root/'filemanager.php'
    target.write_text(re.sub(r"^\$authPasswordHash = '[^']*';$","$authPasswordHash = '"+test_hash(PASSWORD)+"';",SOURCE.read_text(),flags=re.M))
    php_temp,script=json.loads(subprocess.check_output(['php','-r','echo json_encode([sys_get_temp_dir(),realpath($argv[1])]);',str(target)]))
    directory=Path(php_temp)/('fm-auth-'+hashlib.sha256(script.encode()).hexdigest()[:24])
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    server=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        url=f'http://127.0.0.1:{port}/filemanager.php';anon=Client(url)
        for _ in range(100):
            try:anon.request();break
            except OSError:time.sleep(.03)
        assert anon.request(fields={'action':'login_activity','operation':'read'},csrf=False)[0]==403
        anon.login('wrong-password')
        assert anon.request(fields={'action':'login_activity','operation':'read'})[0]==401
        admin=Client(url);status,body,_=admin.login();assert status==200
        admin.csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',body)[1].decode()
        assert b'const blockedLoginIPs = null;' in body
        def activity(operation='read',**fields):
            status,body,_=admin.request(fields={'action':'login_activity','operation':operation,**fields});return status,json.loads(body)
        status,data=activity();assert status==200,data
        assert data['last_success'] and data['failures_24h']==1,data
        row=next(row for row in data['rows'] if row['ip']=='127.0.0.1')
        assert row['agent'] and {e['result'] for e in row['events']}=={'success','wrong_password'}
        assert PASSWORD not in (directory/'login-activity.json').read_text()
        # Seed another address: the local test server intentionally never trusts X-Forwarded-For.
        path=directory/'attempts.json';state=json.loads(path.read_text());now=int(time.time());ip='203.0.113.10';key=hashlib.sha256(ip.encode()).hexdigest()
        state[key]={'ip':ip,'since':now,'last':now,'count':8}
        old='198.51.100.20';state[hashlib.sha256(old.encode()).hexdigest()]={'ip':old,'since':now-1000,'count':8}
        path.write_text(json.dumps(state))
        fresh=Client(url);status,body,_=fresh.login();assert status==200 and b'const blockedLoginIPs = 1;' in body
        assert b'const blockedLoginIPs = null;' in fresh.request()[1]
        assert admin.request(fields={'action':'login_activity','operation':'reset','key':key},csrf=False)[0]==403
        status,data=activity('reset',key=key);assert status==200 and data['blocked_ips']==0
        assert any(e['result']=='limit_reset' for r in data['rows'] for e in r['events'])
        assert activity('reset',key='../attempts.json')[0]==400
        before=(directory/'login-policy.json').read_bytes() if (directory/'login-policy.json').exists() else None
        assert activity('policy',per_ip=10,global_=2)[0]==400
        assert activity('policy',per_ip=0,**{'global':64},window_minutes=15)[0]==400
        status,data=activity('policy',per_ip=3,**{'global':12},window_minutes=5)
        assert status==200 and data['policy']=={'per_ip':3,'global':12,'window_minutes':5}
        bad=Client(url);codes=[bad.login('wrong')[0] for _ in range(9)];assert codes[:3]==[401]*3 and codes[3:]==[429]*6,codes
        status,data=activity();assert status==200 and data['blocked_ips']==1
        local=next(row for row in data['rows'] if row['ip']=='127.0.0.1')
        blocked=[e for e in local['events'] if e['result']=='blocked'];assert len(blocked)==1 and blocked[0]['count']==6
        # Counter reset keeps the activity history, while global limit can be reset separately.
        activity('reset',key=hashlib.sha256(b'127.0.0.1').hexdigest())
        state=json.loads(path.read_text());state['global']={'since':int(time.time()),'count':12};path.write_text(json.dumps(state))
        assert activity()[1]['global_blocked_until']
        assert activity('reset',key='global')[1]['global_blocked_until'] is None
        # Bound retention and count during the next real login event.
        events=[{'ip':ip,'result':'wrong_password','first':now-700000,'last':now-700000,'count':1,'agent':'old','actor':None}]
        events += [{'ip':ip,'result':'wrong_password','first':now,'last':now,'count':1,'agent':'test','actor':None} for _ in range(2100)]
        log=directory/'login-activity.json';log.write_text(json.dumps(events));assert Client(url).login()[0]==200
        stored=json.loads(log.read_text());assert len(stored)<=2000 and all(e['last']>=now-604800 for e in stored)
        assert log.stat().st_size<=1048576 and log.stat().st_mode&0o777==0o600
        assert (directory/'login-policy.json').stat().st_mode&0o777==0o600
        print('PASS: private IP journal, auth/CSRF guards, one-time blocked-IP notice, per-IP/global resets, validated configurable limits, grouped blocked requests and bounded retention.')
    finally:
        server.terminate();server.wait()
        if directory.is_dir():shutil.rmtree(directory)
