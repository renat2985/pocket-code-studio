"""Real local Git/HTTP integration; HTTPS transport is replaced with a temporary bare repo."""
import os,json,re,socket,subprocess,tempfile,time,hashlib
from pathlib import Path
helpers=Path(__file__).with_name('authentication.py').read_text().split("with tempfile.TemporaryDirectory(prefix='fm-auth-tests-')")[0]
ns={'__file__':str(Path(__file__).with_name('authentication.py'))};exec(helpers,ns)
Client=ns['Client'];PASSWORD=ns['PASSWORD'];SOURCE=ns['SOURCE'];test_hash=ns['test_hash']
import shutil
GIT=os.environ.get('FM_TEST_GIT') or shutil.which('git')
assert GIT
with tempfile.TemporaryDirectory(prefix='fm-github-test-') as folder:
    base=Path(folder);root=base/'site';root.mkdir();bare=base/'remote.git';binaries=base/'bin';binaries.mkdir()
    env=dict(os.environ,GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null')
    def git(*args,cwd=root):
        r=subprocess.run([GIT,'-C',str(cwd),*args],capture_output=True,text=True,env=env)
        assert r.returncode==0,(args,r.stderr)
        return r.stdout.strip()
    git('init','-b','main');git('config','user.name','Test');git('config','user.email','test@example.com')
    (root/'.gitignore').write_text('filemanager.php\n');(root/'a.txt').write_text('before\n');(root/'b.txt').write_text('before\n')
    git('add','.');git('commit','-m','Initial');git('init','--bare',str(bare));git('push',str(bare),'main')
    source=SOURCE.read_text();source=re.sub(r"^\$authPasswordHash = '[^']*';$","$authPasswordHash = '"+test_hash(PASSWORD)+"';",source,flags=re.M)
    target=root/'filemanager.php';target.write_text(source)
    stub=binaries/'git';stub.write_text('''#!/usr/bin/env python3
import os,sys,json,subprocess
from pathlib import Path
base=Path(os.environ['FM_TEST_BASE']);args=sys.argv[1:]
# Record arguments only: credentials must never be present here.
with (base/'commands.jsonl').open('a') as f:f.write(json.dumps(args)+'\\n')
if 'push' in args:
 assert os.environ.get('FM_GITHUB_TOKEN')=='github_pat_fixture'
 helper=os.environ['GIT_ASKPASS'];assert 'fixture' not in Path(helper).read_text()
 value=subprocess.check_output([helper,'Password for https://github.com'],env=os.environ).decode().strip()
 assert value=='github_pat_fixture'
 assert args[-2]=='https://github.com/example/private.git'
 assert '--force' not in args
 if (base/'reject-push').exists():sys.exit(1)
 args[-2]=str(base/'remote.git')
 args=['-c','protocol.file.allow=always',*args]
else:assert 'FM_GITHUB_TOKEN' not in os.environ
os.execv(os.environ['FM_TEST_REAL_GIT'],[os.environ['FM_TEST_REAL_GIT'],*args])
''');stub.chmod(0o700)
    serverenv=dict(env,PATH=str(binaries)+os.pathsep+env['PATH'],FM_TEST_BASE=str(base),FM_TEST_REAL_GIT=GIT)
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    process=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root)],env=serverenv,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    storage=Path(tempfile.gettempdir())/('fm-auth-'+hashlib.sha256(str(target.resolve()).encode()).hexdigest()[:24])
    try:
        c=Client(f'http://127.0.0.1:{port}/filemanager.php')
        for _ in range(100):
            try:c.request();break
            except OSError:time.sleep(.03)
        assert c.request(fields={'action':'github'},csrf=False)[0]==403
        status,body,_=c.login();assert status==200
        c.csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',body)[1].decode()
        latest_preview={}
        def request(operation,**fields):
            if operation=='commit_push':
                fields={'head':latest_preview.get('head',''),'branch':latest_preview.get('branch',''),'preview':json.dumps(latest_preview.get('files',[])),**fields}
            status,body,_=c.request(fields={'action':'github','operation':operation,**fields})
            assert b'github_pat_fixture' not in body,body
            data=json.loads(body)
            if operation in ['read','save'] and status==200:
                latest_preview.update(data['repository'])
                latest_preview['files']=[dict(f) for f in latest_preview['files']]
                for file in latest_preview['files']:
                    path=root/file['path']
                    if file['allowed'] and path.is_file():file['hash']=hashlib.sha256(path.read_bytes()).hexdigest()
            return status,data
        status,data=request('read');assert status==200,(status,data)
        assert not data['settings']['has_token'] and data['repository']['branch']=='main'
        fields=dict(url='https://github.com/example/private.git',branch='main',name='Editor Test',email='editor@example.com',token='github_pat_fixture')
        status,data=request('save',**fields);assert status==200,data
        private=next(storage.glob('github-*.json'));assert private.stat().st_mode&0o777==0o600
        assert storage.stat().st_mode&0o777==0o700
        for url in ['https://evil.example/repo.git','https://github.com@example.org/a/b','https://user:secret@github.com/a/b','https://github.com/a/b?x=1']:
            assert request('save',**{**fields,'url':url})[0]==400
        assert request('save',**{**fields,'branch':'--force'})[0]==400
        (root/'a.txt').write_text('selected\n');(root/'b.txt').write_text('not selected\n')
        weird='new ;$(unsafe).txt';(root/weird).write_text('new\n')
        _,data=request('read');revision=data['repository']['revision'];old=git('rev-parse','HEAD');index=(root/'.git/index').read_bytes()
        assert request('commit_push',revision=revision,files=json.dumps(['../outside']),message='No')[0]==400
        assert (root/'.git/index').read_bytes()==index and git('rev-parse','HEAD')==old
        (root/'a.txt').write_text('changed after preview\n')
        assert request('commit_push',revision=revision,files='["a.txt"]',message='Stale')[0]==400
        _,data=request('read');revision=data['repository']['revision']
        (root/'b.txt').write_text('unrelated background change\n')
        (base/'reject-push').touch()
        status,data=request('commit_push',revision=revision,files=json.dumps(['a.txt',weird]),message='Selected files only')
        assert status==400 and data['committed'] is True,data
        new=git('rev-parse','HEAD');assert old!=new
        assert git('show','HEAD:a.txt')=='changed after preview'
        assert git('show','HEAD:b.txt')=='before'
        assert git('diff','--cached','--name-only')==''
        assert git('diff','--name-only')=='b.txt'
        assert git('log','-1','--format=%an <%ae>')=='Editor Test <editor@example.com>'
        assert not (root/'unsafe').exists() and not list(storage.glob('.askpass-*')) and not (root/'.git/index.lock').exists()
        (base/'reject-push').unlink();_,data=request('read')
        snapshot=data['repository']
        (root/'b.txt').write_text('changed after push preview\n')
        assert request('push',head='0'*40,branch='main')[0]==400
        many=root/'many';many.mkdir()
        for i in range(510):(many/str(i)).write_text('untracked\n')
        before_commands=len((base/'commands.jsonl').read_text().splitlines())
        status,data=request('push',revision=snapshot['revision'],head=snapshot['head'],branch=snapshot['branch']);assert status==200,data
        commands=[json.loads(line) for line in (base/'commands.jsonl').read_text().splitlines()[before_commands:]]
        assert not any('status' in cmd or 'diff' in cmd for cmd in commands),'push must not scan working files'
        _,listing=request('read');assert len(listing['repository']['files'])>500
        assert all(f['hash'] is None for f in listing['repository']['files'] if f['allowed'] and (root/f['path']).is_file()),'listing must not hash file contents'
        status,prepared=request('prepare',files='["b.txt"]',preview=json.dumps(listing['repository']['files']),head=listing['repository']['head'],branch='main');assert status==200,prepared
        hashes=[f for f in prepared['repository']['files'] if f['hash'] and f['hash'] not in ['deleted','unsupported']]
        assert len(hashes)==1 and hashes[0]['path']=='b.txt','only selected files should be hashed'
        assert git('rev-parse','refs/heads/main',cwd=bare)==new
        assert git('rev-parse','HEAD')==new
        # A real non-fast-forward rejection must not rewrite either branch.
        other=base/'other';git('clone',str(bare),str(other),cwd=base)
        git('checkout','main',cwd=other);git('config','user.name','Remote',cwd=other);git('config','user.email','remote@example.com',cwd=other)
        (other/'remote.txt').write_text('remote advance\n');git('add','remote.txt',cwd=other);git('commit','-m','Remote advance',cwd=other);git('push','origin','main',cwd=other)
        remote_head=git('rev-parse','HEAD',cwd=other)
        (root/'a.txt').write_text('local advance\n');_,data=request('read')
        status,data=request('commit_push',revision=data['repository']['revision'],files='["a.txt"]',message='Local advance')
        assert status==400 and data['committed'] is True,data
        assert git('rev-parse','refs/heads/main',cwd=bare)==remote_head
        assert git('show','HEAD:a.txt')=='local advance'
        # Foreign staged work is refused and preserved.
        git('add','b.txt');index=(root/'.git/index').read_bytes()
        assert request('read')[0]==400 and (root/'.git/index').read_bytes()==index
        git('reset','--','b.txt')
        # Reject filters and symlinks, and keep local state on rejection.
        link=root/'outside';link.symlink_to('/etc/passwd');_,data=request('read')
        assert next(f for f in data['repository']['files'] if f['path']=='outside')['allowed'] is False
        assert request('commit_push',revision=data['repository']['revision'],files='["outside"]',message='Bad')[0]==400
        git('config','filter.test.clean','false');_,data=request('read')
        assert request('commit_push',revision=data['repository']['revision'],files='["b.txt"]',message='Filtered')[0]==400
        git('config','--unset','filter.test.clean')
        git('config','url.https://evil.example/.insteadOf','https://github.com/');_,data=request('read')
        assert request('push',head=data['repository']['head'],branch=data['repository']['branch'])[0]==400
        git('config','--unset','url.https://evil.example/.insteadOf')
        # Changing destination clears the old token instead of silently sharing it.
        status,data=request('save',**{**fields,'url':'https://github.com/example/other.git','token':''});assert status==200 and not data['settings']['has_token']
        assert 'github_pat_fixture' not in (base/'commands.jsonl').read_text()
        print('PASS: real Git selected commits, private credentials, CSRF, stale preview, staged preservation, failure/retry, symlink/filter/URL guards; push transport redirected to local bare repo.')
    finally:
        process.terminate();process.wait(timeout=5)
        if storage.exists():shutil.rmtree(storage)
