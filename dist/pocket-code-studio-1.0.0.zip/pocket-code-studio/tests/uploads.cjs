const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../filemanager.php'),'utf8');
let sent=0,body,result,refresh=0;const alerts=[],toasts=[];
const fill={style:{},classList:{add(){},remove(){}}},bar={style:{},querySelector:()=>fill};
class Form {constructor(){this.values=[];}append(...value){this.values.push(value);}}
class XHR {constructor(){this.upload={addEventListener(){}};this.handlers={};}open(){}addEventListener(type,fn){this.handlers[type]=fn;}send(data){sent++;body=data;this.status=200;this.responseText=JSON.stringify(result);queueMicrotask(()=>this.handlers.load());}}
const context=vm.createContext({document:{getElementById:()=>bar},currentPath:'/images',FormData:Form,XMLHttpRequest:XHR,
    window:{location:{pathname:'/filemanager.php'},workspaceAlert:(...args)=>alerts.push(args)},editorTabs:new Map(),
    editorFilePath:(name,dir)=>dir+'/'+name,tabHasChanges:tab=>!!tab?.dirty,
    loadFileList:()=>refresh++,loadDirectoryTree(){},showAlert:(...args)=>toasts.push(args),
    requestWorkspace:async()=>({files:{'old.txt':'a'.repeat(64)}})});
const start=source.indexOf('            let uploadBusy = false;'),end=source.indexOf('            // ── Download',start);
vm.runInContext(source.slice(start,end),context);
(async()=>{
    context.confirmUploadReplacement=async names=>{assert.deepEqual(Array.from(names),['old.txt']);return false;};
    await context.uploadFiles([{name:'old.txt',size:3}]);assert.equal(sent,0);
    context.confirmUploadReplacement=async()=>{context.currentPath='/elsewhere';return true;};
    context.currentPath='/images';result={status:'partial',message:'One failed',uploaded:[],failedFiles:['old.txt: Permission denied']};
    await context.uploadFiles([{name:'old.txt',size:3}]);assert.equal(sent,1);
    assert.deepEqual(body.values.find(entry=>entry[0]==='path'),['path','/images']);
    assert.match(alerts.at(-1)[0],/Permission denied/);assert.equal(toasts.length,0);
    context.requestWorkspace=async()=>({files:{'new.txt':null}});
    result={status:'success',message:'Uploaded and verified 1 file.',uploaded:['new.txt']};
    await context.uploadFiles([{name:'new.txt',size:3}]);assert.equal(toasts.at(-1)[0],'Success');assert.equal(bar.style.display,'none');
    context.currentPath='/images';context.requestWorkspace=async()=>({files:{'old.txt':'a'.repeat(64)}});
    context.editorTabs.set('/images/old.txt',{dirty:true});
    await context.uploadFiles([{name:'old.txt',size:3}]);assert.equal(sent,2);assert.match(alerts.at(-1)[0],/unsaved edits/);
    console.log('PASS: cancel prevents upload, destination snapshot, partial errors show details without Success, verified success and dirty-tab guard.');
})().catch(error=>{console.error(error);process.exitCode=1;});
