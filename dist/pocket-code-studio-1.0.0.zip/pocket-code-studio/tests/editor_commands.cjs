const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
const calls = [], tabs = new Map();
function target(name) {
    return {editor: {focus: () => calls.push(name + ':focus'), undo: () => calls.push(name + ':undo')},
        saveFile: () => calls.push(name + ':save'), toggleWrap: () => calls.push(name + ':wrap')};
}
tabs.set('/a', {frame: {contentWindow: target('a')}});
tabs.set('/b', {frame: {contentWindow: target('b')}});
tabs.set('/image', {frame: {contentWindow: {fmImagePreview: true}}});
const buttons = ['save', 'wrap', 'unknown'].map(editorCommand => ({dataset: {editorCommand}}));
const context = vm.createContext({editorTabs: tabs, activeEditorPath: '/a', updateButtonStates() {},
    document: {querySelectorAll: () => buttons}});
const start = source.indexOf('            const editorCommands = {');
const end = source.indexOf("            document.getElementById('menu-show-files')", start);
vm.runInContext(source.slice(start, end), context);
context.updateEditorMenu();
assert.deepEqual(buttons.map(b => b.disabled), [false, false, true]);
context.runEditorCommand('save');
context.activeEditorPath = '/b';
context.runEditorCommand('undo'); context.runEditorCommand('wrap');
context.runEditorCommand('toString');
assert.deepEqual(calls, ['a:save', 'a:focus', 'b:undo', 'b:focus', 'b:wrap']);
context.activeEditorPath = '/image'; context.updateEditorMenu(); context.runEditorCommand('save');
assert.equal(buttons.every(b => b.disabled), true);
context.activeEditorPath = null; context.runEditorCommand('save');
assert.equal(calls.length, 5);
console.log('PASS: active-tab commands, focus behavior, unknown commands, image/file-list guards.');
