const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
const calls = [], tabs = new Map();
function target(name) {
    const state = {wrap:name==='b', invisibles:name==='b', minimap:name==='a'};
    return {state, document:{getElementById:()=>({hidden:!state.minimap}),fullscreenElement:null},
        editor: {focus: () => calls.push(name + ':focus'), undo: () => calls.push(name + ':undo'), getOption:()=>state.invisibles,
            session: {getUseWrapMode:()=>state.wrap,foldAll: () => calls.push(name + ':foldall'), unfold: () => calls.push(name + ':unfoldall')}},
        saveFile: () => calls.push(name + ':save'),
        toggleWrap: () => {state.wrap=!state.wrap;calls.push(name + ':wrap');},
        toggleInvisibles: () => {state.invisibles=!state.invisibles;calls.push(name + ':invisibles');}};
}
tabs.set('/a', {frame: {contentWindow: target('a')}});
tabs.set('/b', {frame: {contentWindow: target('b')}});
tabs.set('/image', {frame: {contentWindow: {fmImagePreview: true}}});
const buttons = ['save', 'wrap', 'map', 'invisibles', 'fullscreen', 'unknown'].map(editorCommand => ({dataset: {editorCommand},setAttribute(key,value){this[key]=value;}}));
const context = vm.createContext({editorTabs: tabs, activeEditorPath: '/a', updateButtonStates() {},
    document: {querySelectorAll: () => buttons,addEventListener(){}}});
const start = source.indexOf('            const editorCommands = {');
const end = source.indexOf("            document.getElementById('menu-show-files')", start);
vm.runInContext(source.slice(start, end), context);
context.updateEditorMenu();
assert.deepEqual(buttons.map(b => b.disabled), [false, false, false, false, false, true]);
assert.deepEqual(buttons.slice(1,5).map(b=>b['aria-pressed']),['false','true','false','false']);
context.runEditorCommand('save');
context.activeEditorPath = '/b'; context.updateEditorMenu();
assert.deepEqual(buttons.slice(1,5).map(b=>b['aria-pressed']),['true','false','true','false']);
context.runEditorCommand('undo'); context.runEditorCommand('wrap');
context.runEditorCommand('invisibles');
assert.equal(buttons[1]['aria-pressed'],'false');assert.equal(buttons[3]['aria-pressed'],'false');
tabs.get('/b').frame.contentWindow.document.fullscreenElement={};context.updateEditorMenu();assert.equal(buttons[4]['aria-pressed'],'true');
tabs.get('/b').frame.contentWindow.document.fullscreenElement=null;context.updateEditorMenu();assert.equal(buttons[4]['aria-pressed'],'false');
context.runEditorCommand('foldall'); context.runEditorCommand('unfoldall');
context.runEditorCommand('toString');
assert.deepEqual(calls, ['a:save', 'a:focus', 'b:undo', 'b:focus', 'b:wrap', 'b:invisibles', 'b:foldall', 'b:focus', 'b:unfoldall', 'b:focus']);
context.activeEditorPath = '/image'; context.updateEditorMenu(); context.runEditorCommand('save'); context.runEditorCommand('foldall'); context.runEditorCommand('unfoldall');
assert.equal(buttons.every(b => b.disabled), true);
assert(buttons.slice(1,5).every(b=>b['aria-pressed']==='false'));
context.activeEditorPath = null; context.runEditorCommand('save');
assert.equal(calls.length, 10);
console.log('PASS: active-tab commands, focus behavior, unknown commands, image/file-list guards.');

const stored = new Map(), visibility = [], pressed = [];
const prefs = vm.createContext({window: {editor: {setOption: (key,value) => visibility.push(['self',key,value])}},
 localStorage: {setItem: (key,value) => stored.set(key,value)}, document: {querySelectorAll: selector => selector.startsWith('iframe')
 ? [{contentWindow: {editor: {setOption: (key,value) => visibility.push(['frame',key,value])}}}, {contentWindow: {fmImagePreview:true}}]
 : [{setAttribute: (key,value) => pressed.push(value)}]}});
const prefStart = source.indexOf('    window.setEditorPreference = function(');
vm.runInContext(source.slice(prefStart,source.indexOf('    window.workspaceConfirm',prefStart)),prefs);
prefs.window.setShowInvisibles(true);
assert.equal(stored.get('ke_invisibles'),'true');assert.equal(visibility.length,2);assert.equal(pressed.at(-1),'true');
prefs.window.setShowInvisibles(false,false);
assert.equal(stored.get('ke_invisibles'),'true');assert.equal(visibility.at(-1)[2],false);assert.equal(pressed.at(-1),'false');
console.log('PASS: invisibles update all text editors, skip images, persist preferences and reflect menu state.');
for (const [option,key] of [['displayIndentGuides','ke_indent_guides'],['enableLiveAutocompletion','ke_live_autocomplete']]) {
    prefs.window.setEditorPreference(option,false);
    assert.equal(stored.get(key),'false');assert.deepEqual(visibility.at(-1),['frame',option,false]);assert.equal(pressed.at(-1),'false');
    prefs.window.setEditorPreference(option,true,false);
    assert.equal(stored.get(key),'false');assert.equal(visibility.at(-1)[2],true);assert.equal(pressed.at(-1),'true');
}
let detached=0;prefs.window.editor.completer={detach:()=>detached++};
prefs.window.setEditorPreference('enableLiveAutocompletion',false);assert.equal(detached,1);
const previous=visibility.length;prefs.window.setEditorPreference('toString',true);assert.equal(visibility.length,previous);
console.log('PASS: indent/autocompletion preferences synchronize and persist; disabling suggestions closes the popup.');
