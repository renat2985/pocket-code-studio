"""Check real POSIX ownership and numeric fallback when POSIX lookup is disabled."""
import json,os,pwd,grp,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'filemanager.php').read_text()
start=source.index('function getFileOwnership(')
helper=source[start:source.index('// Function to get directory contents',start)]
path=root/'README.md';stat=path.stat()
script=helper+'echo json_encode(getFileOwnership($argv[1]));'
normal=json.loads(subprocess.check_output(['php','-r',script,str(path)]))
assert normal['uid']==stat.st_uid and normal['gid']==stat.st_gid
assert normal['owner']==pwd.getpwuid(stat.st_uid).pw_name
assert normal['group']==grp.getgrgid(stat.st_gid).gr_name
fallback=json.loads(subprocess.check_output(['php','-d','disable_functions=posix_getpwuid,posix_getgrgid','-r',script,str(path)]))
assert fallback=={'owner':str(stat.st_uid),'group':str(stat.st_gid),'uid':stat.st_uid,'gid':stat.st_gid}
missing=json.loads(subprocess.check_output(['php','-r',script,str(root/'does-not-exist-for-ownership-test')]))
assert missing=={'owner':'—','group':'—','uid':None,'gid':None}
print('PASS: ownership names, numeric fallback without POSIX extension, unavailable-file metadata.')
