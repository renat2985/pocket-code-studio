"""Security regression tests; all password changes target a temporary copy."""
import base64,hashlib,http.cookiejar,json,re,shutil,socket,subprocess,tempfile,time,urllib.request,urllib.error,urllib.parse
from pathlib import Path
SOURCE=Path(__file__).resolve().parents[1]/'filemanager.php'
PASSWORD='Test-only-password-2026'
NEW='Changed-test-password-2026'
def test_hash(password):return subprocess.check_output(['php','-r','echo password_hash($argv[1], PASSWORD_BCRYPT, ["cost"=>4]);',password]).decode()
class Client:
    def __init__(self,url):
        self.url=url;self.jar=http.cookiejar.CookieJar();self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar));self.csrf=None
    def request(self,query='',fields=None,payload=None,csrf=True):
        headers={};data=None
        if fields is not None: data=urllib.parse.urlencode(fields).encode()
        if payload is not None:data=json.dumps(payload).encode();headers['Content-Type']='application/json'
        if data is not None and csrf and self.csrf:headers['X-FM-CSRF']=self.csrf
        req=urllib.request.Request(self.url+query,data=data,headers=headers)
        try:
            with self.opener.open(req,timeout=8) as r:return r.status,r.read(),r.headers
        except urllib.error.HTTPError as e:return e.code,e.read(),e.headers
    def login(self,password=PASSWORD):
        status,body,headers=self.request()
        match=re.search(rb'name="fm_csrf" value="([a-f0-9]+)"',body)
        assert match,(status,body[:200])
        self.csrf=match[1].decode()
        return self.request(fields={'fm_auth_action':'login','password':password})
with tempfile.TemporaryDirectory(prefix='fm-auth-tests-') as folder:
    root=Path(folder);target=root/'filemanager.php'
    source=SOURCE.read_text();source=re.sub(r"^\$authPasswordHash = '[^']*';$","$authPasswordHash = '"+test_hash(PASSWORD)+"';",source,flags=re.M)
    target.write_text(source)
    fixture=root/'private.txt';original=b'PRIVATE-CONTENT\n';fixture.write_bytes(original)
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    proc=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    url=f'http://127.0.0.1:{port}/filemanager.php'
    try:
        for _ in range(100):
            try:urllib.request.urlopen(url,timeout=.2)
            except urllib.error.HTTPError:break
            except OSError:time.sleep(.03)
        anon=Client(url)
        status,body,headers=anon.request();assert status==401 and b'PRIVATE-CONTENT' not in body
        assert b'Pocket Code Studio' not in body and b'File Manager' not in body and b'File access' not in body
        assert b'<title>Sign in</title>' in body
        assert 'HttpOnly' in headers.get('Set-Cookie','') and 'SameSite=Strict' in headers.get('Set-Cookie','')
        q='?editor=1&filename='+urllib.parse.quote(str(fixture),safe='')
        assert anon.request(q)[0]==401
        assert anon.request(q+'&check=1')[0]==401
        for action in ['list','tree','search','download','delete','create_file','settings','empty_trash']:
            status,body,_=anon.request('?action='+action+'&path=/&file=private.txt')
            assert status==401 and original not in body,(action,status)
            assert anon.request(fields={'action':action,'path':'','name':'pwn.txt'},csrf=False)[0]==403
        assert fixture.read_bytes()==original and not (root/'pwn.txt').exists()
        assert anon.login('wrong')[0]==401
        first=Client(url);status,body,_=first.login();assert status==200 and b'Application menus' in body
        match=re.search(rb'const fmCSRF = "([a-f0-9]+)";',body);first.csrf=match[1].decode()
        second=Client(url);status,body,_=second.login();assert status==200
        second.csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',body)[1].decode()
        image=root/'preview.png'
        image_bytes=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a5WQAAAAASUVORK5CYII=')
        image.write_bytes(image_bytes)
        image_query='?editor=1&filename='+urllib.parse.quote(str(image),safe='')
        assert Client(url).request(image_query+'&image=1')[0]==401
        status,preview,_=first.request(image_query)
        assert status==200 and b'id="image-preview"' in preview and preview.rstrip().endswith(b'</html>')
        status,raw,image_headers=first.request(image_query+'&image=1')
        assert status==200 and raw==image_bytes and image_headers['Content-Type']=='image/png'
        assert 'sandbox' in image_headers['Content-Security-Policy']
        assert first.request(image_query,payload={})[0]==405 and image.read_bytes()==image_bytes
        assert json.loads(first.request(q+'&check=1')[1])['kind']=='text'
        assert json.loads(first.request(image_query+'&check=1')[1])['kind']=='image'
        status,listing,_=first.request(fields={'action':'list','path':''})
        assert status==200
        listed=next(item for item in json.loads(listing)['data'] if item['name']=='private.txt')
        assert isinstance(listed['uid'],int) and isinstance(listed['gid'],int)
        assert listed['owner'] and listed['group']
        assert first.request('?action=delete&items=private.txt')[0]==405 and fixture.read_bytes()==original
        assert first.request(fields={'action':'create_file','name':'../escape.txt'})[0]==400
        assert first.request(fields={'action':'tree','path':'/../../'})[0]>=400
        for label,page in [('manager',body),('editor',first.request(q)[1])]:
            assert page.rstrip().endswith(b'</html>'),(label,'HTML response truncated',page[-600:])
            for index,script in enumerate(re.findall(rb'<script(?:\s[^>]*)?>(.*?)</script>',page,re.S)):
                if not script.strip():continue
                script_file=root/f'{label}-{index}.js';script_file.write_bytes(script)
                checked=subprocess.run(['node','--check',str(script_file)],capture_output=True)
                assert checked.returncode==0,checked.stderr
                script_file.unlink()
        offsite=subprocess.check_output(['php','-r','$_SERVER["REMOTE_ADDR"]="203.0.113.1"; $_SERVER["REQUEST_METHOD"]="GET"; require $argv[1];',str(target)])
        assert offsite==b'HTTPS is required.' 
        assert first.request(fields={'action':'create_file','name':'pwn.txt'},csrf=False)[0]==403
        assert first.request(fields={'action':'create_file','name':'pwn.txt'},csrf=True)[0]==200
        assert first.request(q)[0]==200
        content=b'Changed securely\n'
        payload={'base_hash':hashlib.sha256(original).hexdigest(),'content_base64':base64.b64encode(content).decode(),'byte_length':len(content)}
        assert first.request(q,payload=payload,csrf=False)[0]==403 and fixture.read_bytes()==original
        assert first.request(q,payload=payload)[0]==200 and fixture.read_bytes()==content
        change={'fm_auth_action':'change_password','current_password':PASSWORD,'new_password':NEW,'confirm_password':NEW}
        before=target.read_bytes()
        assert first.request(fields={**change,'current_password':'wrong'})[0]==403 and target.read_bytes()==before
        assert first.request(fields=change,csrf=False)[0]==403 and target.read_bytes()==before
        assert first.request(fields={**change,'new_password':'short'})[0]==400 and target.read_bytes()==before
        status,body,_=first.request(fields=change);assert status==200,(status,body)
        assert target.read_bytes()!=before and PASSWORD.encode() not in target.read_bytes() and NEW.encode() not in target.read_bytes()
        assert subprocess.run(['php','-l',str(target)],capture_output=True).returncode==0
        assert second.request(q)[0]==401
        assert first.request(q)[0]==200
        assert Client(url).login(PASSWORD)[0]==401
        last=Client(url);status,body,_=last.login(NEW);assert status==200
        last.csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',body)[1].decode()
        assert last.request(fields={'fm_auth_action':'logout'})[0]==200
        assert last.request(q)[0]==401
        bad=Client(url)
        codes=[bad.login('bad-password')[0] for _ in range(9)]
        assert 429 in codes,codes
        assert fixture.read_bytes()==content
        php_temp,php_script=json.loads(subprocess.check_output(['php','-r','echo json_encode([sys_get_temp_dir(),realpath($argv[1])]);',str(target)]))
        runtime=Path(php_temp)/('fm-auth-'+hashlib.sha256(php_script.encode()).hexdigest()[:24]);shutil.rmtree(runtime)
        backupdir=Path(php_temp)/('fm-editor-'+hashlib.sha256((php_script+'|'+str(root.resolve())).encode()).hexdigest()[:24]);shutil.rmtree(backupdir)
        print('PASS: anonymous requests denied, HttpOnly/SameSite, login, CSRF on forms/JSON, authenticated save, password-change validation, atomic hash update, old-session revocation, logout, brute-force limit, PHP syntax.')
    finally:proc.terminate();proc.wait(timeout=5)
