"""HTTP integration checks using a deterministic Git stub; no real repository is modified."""
import os, difflib
from pathlib import Path
import base64,json,re,socket,subprocess,tempfile,time,urllib.request,urllib.error,urllib.parse
# Reuse the authentication HTTP client without executing that module's test run.
helpers=Path(__file__).with_name('authentication.py').read_text().split("with tempfile.TemporaryDirectory(prefix='fm-auth-tests-')")[0]
namespace={'__file__':str(Path(__file__).with_name('authentication.py'))};exec(helpers,namespace)
Client=namespace['Client'];PASSWORD=namespace['PASSWORD'];SOURCE=namespace['SOURCE'];test_hash=namespace['test_hash']
with tempfile.TemporaryDirectory(prefix='fm-git-test-') as folder:
    root=Path(folder);source=SOURCE.read_text();source=re.sub(r"^\$authPasswordHash = '[^']*';$","$authPasswordHash = '"+test_hash(PASSWORD)+"';",source,flags=re.M)
    (root/'filemanager.php').write_text(source);fixture=root/'tracked ;$(unsafe).txt';fixture.write_text('saved\n');baseline='original\n'
    binaries=root/'bin';binaries.mkdir();log=root/'commands.jsonl'
    stub=binaries/'git';stub.write_text('''#!/usr/bin/env python3
import sys,os,json,difflib
from pathlib import Path
args=sys.argv[1:];root=Path(os.environ['FM_GIT_TEST_ROOT'])
with open(root/'commands.jsonl','a') as f:f.write(json.dumps(args)+'\\n')
i=args.index('-C');cmd=args[i+2:]
if (root/'git-unavailable').exists():
 print('fatal: not a git repository',file=sys.stderr);sys.exit(128)
if cmd[0]=='rev-parse':print(root)
elif cmd[0]=='status':sys.stdout.write(' M tracked ;$(unsafe).txt\\0?? new.txt\\0')
elif cmd[0]=='ls-tree':
 if cmd[-1]=='tracked ;$(unsafe).txt':sys.stdout.write('100644 blob '+'a'*40+'\\t'+cmd[-1]+'\\0')
elif cmd[0]=='cat-file':sys.stdout.write('original\\n')
elif cmd[0]=='diff':
 a,b=map(Path,cmd[-2:]);x=a.read_text();y=b.read_text();sys.stdout.write(''.join(difflib.unified_diff(x.splitlines(True),y.splitlines(True),fromfile=str(a),tofile=str(b))));sys.exit(0 if x==y else 1)
else:sys.exit(10)
''');stub.chmod(0o700)
    env=dict(os.environ,PATH=str(binaries)+os.pathsep+os.environ['PATH'],FM_GIT_TEST_ROOT=str(root))
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    process=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        client=Client(f'http://127.0.0.1:{port}/filemanager.php')
        for _ in range(100):
            try:client.request();break
            except OSError:time.sleep(.03)
        assert client.request(fields={'action':'git_status'},csrf=False)[0]==403
        login_status,login_body,_=client.login();assert login_status==200
        client.csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',login_body)[1].decode()
        status,body,_=client.request(fields={'action':'git_status'});assert status==200,(status,body)
        assert json.loads(body)['files']=={'tracked ;$(unsafe).txt':'M','new.txt':'U'}
        def diff(file,content):return client.request(fields={'action':'git_diff','file':str(file),'content_base64':base64.b64encode(content).decode()})
        status,body,_=diff(fixture,b'unsaved <script>alert(1)</script>\n');data=json.loads(body);assert status==200 and '-original' in data['diff'] and '+unsaved <script>' in data['diff'] and not data['untracked']
        assert fixture.read_text()=='saved\n'
        status,body,_=diff(fixture,b'original\n');assert status==200 and not json.loads(body)['diff'].strip()
        new=root/'new.txt';new.write_text('new\n');status,body,_=diff(new,b'new\n');assert status==200 and json.loads(body)['untracked'] and '+new' in json.loads(body)['diff']
        assert diff('/etc/passwd',b'x')[0]==400
        assert diff(fixture,b'\x00binary')[0]==400
        meta=root/'.git';meta.mkdir();secret=meta/'config';secret.write_text('secret');assert diff(secret,b'x')[0]==400
        commands=[json.loads(line) for line in log.read_text().splitlines()];assert all(c[c.index('-C')+2] in ['rev-parse','status','ls-tree','cat-file','diff'] for c in commands)
        assert all('--literal-pathspecs' in c and '--no-optional-locks' in c for c in commands)
        assert not (root/'unsafe').exists()
        (root/'git-unavailable').touch()
        status,body,_=client.request(fields={'action':'git_status'});data=json.loads(body)
        assert status==200 and data['available'] is False and data['files']=={},(status,data)
        assert diff(fixture,b'original\n')[0]==400
        print('PASS: authenticated Git status/diff, unsaved text, untracked and unchanged files, shell-safe filenames, traversal/binary/metadata guards, read-only command allowlist. Git process mocked.')
    finally:process.terminate();process.wait(timeout=5)
