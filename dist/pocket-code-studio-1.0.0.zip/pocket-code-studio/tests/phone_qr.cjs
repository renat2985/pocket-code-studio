const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
const rects = [], errors = [], scripts = [], listeners = {};
const canvas = {getContext: () => ({fillRect: (...args) => rects.push(args)})};
const elements = {'phone-qr': canvas};
for (const id of ['phone-file-name', 'phone-file-link', 'phoneModal', 'phone-qr-status', 'phone-qr-retry', 'phone-copy-link'])
    elements[id] = {addEventListener: (event, fn) => {listeners[id + ':' + event] = fn;}};
let shown = 0, copied;
const context = vm.createContext({PUBLIC_WORKSPACE_BASE: '', location: {origin: 'https://example.com'}, setTimeout, clearTimeout,
    document: {getElementById: id => elements[id], createElement: () => ({remove() {this.removed = true;}}), head: {appendChild: script => scripts.push(script)}},
    navigator: {clipboard: {writeText: async text => {copied = text;}}},
    showAlert: (...args) => errors.push(args),
    bootstrap: {Modal: {getOrCreateInstance: () => ({show: () => shown++})}}});
context.window = context; context.workspaceToast = () => {};
const start = source.indexOf('            function browserFileURL(');
vm.runInContext(source.slice(start, source.indexOf('            function selectedBrowserFile()', start)), context);
const mockQR = () => ({addData(url) {this.url = url;}, make() {}, getModuleCount: () => 21, isDark: (r,c) => (r+c)%2 === 0});
(async () => {
    assert.equal(scripts.length, 0, 'no CDN request before use');
    const first = context.showPhoneQR('first.php', '');
    const latest = context.showPhoneQR('a #?.png', '/images');
    assert.equal(scripts.length, 1, 'concurrent opens share one load');
    assert.equal(canvas.hidden, true);
    assert.match(elements['phone-qr-status'].textContent, /Loading/);
    assert.equal(scripts[0].src, 'https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js');
    context.qrcode = mockQR; scripts[0].onload(); await Promise.all([first, latest]);
    assert.equal(elements['phone-file-link'].href, 'https://example.com/images/a%20%23%3F.png');
    assert.equal(elements['phone-file-name'].textContent, 'a #?.png');
    assert.equal(canvas.hidden, false); assert.equal(rects.length, 222, 'only latest request renders');
    assert.equal(canvas.width, canvas.height); assert.ok(canvas.width > 100);
    for (const [x,y,w,h] of rects.slice(1)) {
        assert.equal(w, 6); assert.equal(h, 6);
        assert.ok(x >= 24 && y >= 24 && x < canvas.width - 24 && y < canvas.height - 24);
    }
    await context.showPhoneQR('cached.php', ''); assert.equal(scripts.length, 1);
    await listeners['phone-copy-link:click'](); assert.equal(copied, 'https://example.com/cached.php');
    delete context.qrcode; vm.runInContext('phoneQRLibraryPromise = null;', context);
    const failing = context.showPhoneQR('failed.php', ''); scripts[1].onerror(); await failing;
    assert.equal(elements['phone-qr-retry'].hidden, false); assert.equal(canvas.hidden, true);
    assert.match(elements['phone-qr-status'].textContent, /retry or copy/);
    assert.equal(elements['phone-file-link'].href, 'https://example.com/failed.php');
    const retry = context.showPhoneQR('retry.php', ''); assert.equal(scripts.length, 3);
    context.qrcode = mockQR; scripts[2].onload(); await retry; assert.equal(canvas.hidden, false);
    context.PUBLIC_WORKSPACE_BASE = null;
    await context.showPhoneQR('file.php', ''); assert.equal(errors.length, 1);
    console.log('PASS: lazy pinned CDN load, shared requests, cached reuse, rendering, failure/retry and copy link.');
})().catch(error => {console.error(error); process.exitCode = 1;});
