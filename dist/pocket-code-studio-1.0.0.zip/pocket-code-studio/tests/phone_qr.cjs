const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
const rects = [], errors = [], canvas = {getContext: () => ({fillRect: (...args) => rects.push(args)})};
const elements = {'phone-qr': canvas, 'phone-file-name': {}, 'phone-file-link': {}, phoneModal: {}};
let shown = 0;
const context = vm.createContext({PUBLIC_WORKSPACE_BASE: '', location: {origin: 'https://example.com'},
    document: {getElementById: id => elements[id]}, showAlert: (...args) => errors.push(args),
    bootstrap: {Modal: {getOrCreateInstance: () => ({show: () => shown++})}}});
let start = source.indexOf('var qrcode = function()');
vm.runInContext(source.slice(start, source.indexOf('</script>', start)), context);
start = source.indexOf('            function browserFileURL(');
vm.runInContext(source.slice(start, source.indexOf('            function selectedBrowserFile()', start)), context);
context.showPhoneQR('a #?.png', '/images');
assert.equal(shown, 1); assert.equal(errors.length, 0);
assert.equal(elements['phone-file-link'].href, 'https://example.com/images/a%20%23%3F.png');
assert.equal(elements['phone-file-name'].textContent, 'a #?.png');
assert.equal(canvas.width, canvas.height); assert.ok(canvas.width > 100);
assert.deepEqual(rects[0], [0, 0, canvas.width, canvas.height]);
for (const [x,y,w,h] of rects.slice(1)) {
    assert.equal(w, 6); assert.equal(h, 6);
    assert.ok(x >= 24 && y >= 24 && x < canvas.width - 24 && y < canvas.height - 24);
}
context.PUBLIC_WORKSPACE_BASE = null;
context.showPhoneQR('file.php', ''); assert.equal(errors.length, 1); assert.equal(shown, 1);
console.log('PASS: embedded QR generation, escaped file URL, quiet zone, canvas rendering and error handling.');
