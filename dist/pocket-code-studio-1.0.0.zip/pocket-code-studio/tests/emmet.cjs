const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../filemanager.php'),'utf8');
let mode='ace/mode/text',resolveLoad,loads=0,ready=false,boundTab,expand=true,expanded=0,normalTabs=0,detached=0;
const values=new Map(),options=[],alerts=[];
const command={name:'emmet:expand_abbreviation_with_tab'};
const extension={setCore(core){assert.equal(core,window.emmet);},commands:{commands:{[command.name]:command}},isAvailable:()=>true,
 runEmmetCommand(){expanded++;return expand;}};
const document={addEventListener(){},querySelectorAll:()=>[]};
const window={document,emmet:{},loadEmmet:()=>{loads++;return new Promise(resolve=>resolveLoad=()=>{ready=true;resolve();});},workspaceAlert:m=>alerts.push(m)};window.parent=window;
const editor={session:{getMode:()=>({$id:mode}),on(){}},setOption:(k,v)=>options.push([k,v]),completer:{commands:{Tab:()=>normalTabs++},keyboardHandler:{bindKeys:keys=>boundTab=keys.Tab},detach:()=>detached++}};
const context=vm.createContext({window,document,editor,queueMicrotask,localStorage:{getItem:k=>values.get(k)},ace:{require:()=>ready?extension:null}});
const start=source.indexOf('        // Emmet expands abbreviations');vm.runInContext(source.slice(start,source.indexOf('        // Inline comparison uses',start)),context);
(async()=>{
 await window.applyEmmetPreference();assert.equal(loads,0);assert.equal(window.emmetEnabled,false);
 mode='ace/mode/html';const pending=window.applyEmmetPreference();assert.equal(window.emmetEnabled,true);values.set('ke_emmet','false');await window.applyEmmetPreference();resolveLoad();await pending;assert(!options.some(([,v])=>v===true),'cancel stale activation');
 values.delete('ke_emmet');const enabled=window.applyEmmetPreference();resolveLoad();await enabled;assert.deepEqual(options.at(-1),['enableEmmet',true]);
 boundTab(editor);assert.equal(expanded,1);assert.equal(detached,1);assert.equal(normalTabs,0);
 expand=false;boundTab(editor);assert.equal(normalTabs,1,'fall back to ordinary autocomplete Tab when no abbreviation expands');
 values.set('ke_emmet','false');await window.applyEmmetPreference();boundTab(editor);assert.equal(normalTabs,2);assert.deepEqual(options.at(-1),['enableEmmet',false]);
 mode='ace/mode/php';values.delete('ke_emmet');await window.applyEmmetPreference();assert.equal(window.emmetAvailable(),false);assert.equal(window.emmetEnabled,false);
 mode='ace/mode/html';window.loadEmmet=async()=>{throw Error('CDN unavailable');};await window.applyEmmetPreference();assert.equal(window.emmetEnabled,false);assert.equal(alerts.length,1);
 console.log('PASS: HTML-only Emmet, saved opt-out, stale load cancellation, autocomplete Tab priority/fallback and CDN failure.');
})().catch(e=>{console.error(e);process.exitCode=1;});
