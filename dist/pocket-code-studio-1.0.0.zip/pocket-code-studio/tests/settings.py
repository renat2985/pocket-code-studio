"""Settings persistence regression tests; all source rewrites target a temporary copy."""
from pathlib import Path
import base64,hashlib,json,os,re,shutil,socket,subprocess,tempfile,time
helpers=Path(__file__).with_name('authentication.py').read_text().split("with tempfile.TemporaryDirectory(prefix='fm-auth-tests-')")[0]
namespace={'__file__':str(Path(__file__).with_name('authentication.py'))};exec(helpers,namespace)
Client=namespace['Client'];PASSWORD=namespace['PASSWORD'];SOURCE=namespace['SOURCE'];test_hash=namespace['test_hash']
with tempfile.TemporaryDirectory(prefix='pcs-settings-test-') as folder:
    root=Path(folder);target=root/'filemanager.php'
    source=re.sub(r"^\$authPasswordHash = '[^']*';$","$authPasswordHash = '"+test_hash(PASSWORD)+"';",SOURCE.read_text(),flags=re.M)
    target.write_text(source);target.chmod(0o640)
    legacy=root/'.fm-config';legacy_data={'timezone':'Europe/Riga','date_format':'Y-m-d H:i','font_size':'18px'};legacy.write_text(json.dumps(legacy_data));legacy_bytes=legacy.read_bytes()
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    process=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    auth_dir=None
    try:
        client=Client(f'http://127.0.0.1:{port}/filemanager.php')
        for _ in range(100):
            try:client.request();break
            except OSError:time.sleep(.03)
        fields={'action':'settings','timezone':'UTC','dateformat':"Y-m-d 'quoted' \\ ✓ <?php echo 1; ?>",'fontSize':'20px'}
        assert client.request(fields=fields,csrf=False)[0]==403 and target.read_text()==source
        status,body,_=client.login();assert status==200 and b'18px' in body
        client.csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',body)[1].decode()
        def settings(**updates):
            status,body,_=client.request(fields={**fields,**updates});return status,json.loads(body)
        for changes in [{'timezone':'Bad/Timezone'},{'fontSize':'16px; color:red'},{'fontSize':'99px'},{'dateformat':'x\n'},{'dateformat':'x'*129}]:
            assert settings(**changes)[1]['status']=='error'
            assert target.read_text()==source
        status,result=settings();assert status==200 and result['status']=='success',result
        updated=target.read_text();match=re.search(r"^\$workspaceSettingsBase64 = '([^']*)';$",updated,re.M);assert match
        stored=json.loads(base64.b64decode(match[1]));assert stored=={'timezone':'UTC','date_format':fields['dateformat'],'font_size':'20px'}
        restored=re.sub(r"^\$workspaceSettingsBase64 = '[^']*';$","$workspaceSettingsBase64 = '';",updated,flags=re.M);assert restored==source
        assert target.stat().st_mode&0o777==0o640 and legacy.read_bytes()==legacy_bytes
        assert subprocess.run(['php','-l',str(target)],stdout=subprocess.DEVNULL).returncode==0
        assert settings()[1]['status']=='success' and target.read_text()==updated
        status,body,_=client.request();assert status==200 and b'20px' in body and b'UTC' in body
        hardlink=root/'source-link';os.link(target,hardlink)
        assert settings(fontSize='22px')[1]['status']=='error' and target.read_text()==updated
        hardlink.unlink()
        assert settings(fontSize='22px')[1]['status']=='success'
        legacy.unlink();assert client.request()[0]==200 and not legacy.exists()
        # Unified form validates everything before changing either configuration field.
        unified={**fields,'action':'','fm_auth_action':'save_settings','fontSize':'24px','current_password':PASSWORD,'new_password':'Unified-settings-password-2026','confirm_password':'Unified-settings-password-2026'}
        before=target.read_bytes()
        for bad in [{'current_password':'wrong'},{'confirm_password':'mismatch'},{'timezone':'Bad/Timezone'},{'fontSize':'bad'}]:
            status,body,_=client.request(fields={**unified,**bad})
            assert status>=400 and json.loads(body)['status']=='error' and target.read_bytes()==before
        assert client.request(fields=unified,csrf=False)[0]==403 and target.read_bytes()==before
        # Empty password fields save only settings and preserve the old hash.
        status,body,_=client.request(fields={**unified,'current_password':'','new_password':'','confirm_password':''})
        assert status==200 and json.loads(body)['password_changed'] is False
        unchanged_hash=re.search(rb"^\$authPasswordHash = '[^']*';$",target.read_bytes(),re.M)[0]
        assert unchanged_hash==re.search(rb"^\$authPasswordHash = '[^']*';$",before,re.M)[0]
        status,body,_=client.request(fields=unified)
        assert status==200 and json.loads(body)['password_changed'] is True and b'24px' in client.request()[1]
        assert re.search(rb"^\$authPasswordHash = '[^']*';$",target.read_bytes(),re.M)[0]!=unchanged_hash
        inline=json.loads(base64.b64decode(re.search(rb"^\$workspaceSettingsBase64 = '([^']*)';$",target.read_bytes(),re.M)[1]));assert inline['font_size']=='24px'
        auth_dir=Path(subprocess.check_output(['php','-r','echo sys_get_temp_dir();']).decode())/('fm-auth-'+hashlib.sha256(str(target.resolve()).encode()).hexdigest()[:24])
        backups=list(auth_dir.glob('configuration-*.bak'));assert backups and any(p.read_text()==source for p in backups)
        assert all(p.stat().st_mode&0o777==0o600 for p in backups)
        assert not list(root.glob('.fm-auth-save-*'))
        print('PASS: protected settings, validation, legacy import, exact single-line source update, Unicode/quotes, persistence, mode/backup verification, no-op, hard-link failure, password-change coexistence, unified all-or-nothing settings/password, no new .fm-config.')
    finally:
        process.terminate();process.wait(timeout=5)
        if auth_dir and auth_dir.exists():shutil.rmtree(auth_dir)
