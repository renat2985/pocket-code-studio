// Exercise the actual responsive functions with lightweight DOM/editor doubles.
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const source = fs.readFileSync(require('path').join(__dirname,'../filemanager.php'),'utf8');
function extract(start,end) { return source.slice(source.indexOf(start),source.indexOf(end,source.indexOf(start))); }
const classes = new Set();
const store = new Map();
const document = {body:{classList:{toggle(name,on){if(on)classes.add(name);else classes.delete(name);}}},createElement(){return {value:'',textContent:''};}};
const editor={wrap:null,resizes:0,session:{setUseWrapMode(value){editor.wrap=value;}},resize(){editor.resizes++;}};
const context={document,editor,mobileEditorQuery:{matches:true},minimap:{hidden:false},localStorage:{getItem(key){return store.get(key)??null;},setItem(key,value){store.set(key,value);}},scheduleMinimap(){},wrapEnabled:false};
vm.createContext(context);
vm.runInContext(extract('        function applyResponsiveEditor() {','        mobileEditorQuery.addEventListener'),context);
vm.runInContext(extract('        function toggleMinimap() {','        function navigateMinimap'),context);
context.applyResponsiveEditor();assert.equal(editor.wrap,true);assert.equal(context.minimap.hidden,true);assert(classes.has('minimap-hidden'));
context.toggleMinimap();assert.equal(store.get('ke_minimap_mobile'),'true');assert.equal(context.minimap.hidden,false);
context.mobileEditorQuery.matches=false;context.applyResponsiveEditor();assert.equal(editor.wrap,false);assert.equal(context.minimap.hidden,false);
context.toggleMinimap();assert.equal(store.get('ke_minimap'),'false');assert.equal(store.get('ke_minimap_mobile'),'true');
context.mobileEditorQuery.matches=true;context.applyResponsiveEditor();assert.equal(context.minimap.hidden,false);
context.editorTabs=new Map([['/hello.php',{dirty:false}],['/<script>.txt',{dirty:true}]]);
context.activeEditorPath='/hello.php';context.mobileTabsSelect={children:[],replaceChildren(child){this.children=[child];},append(child){this.children.push(child);}};
vm.runInContext(extract('            function refreshMobileTabs() {','            function closeMobileMenu'),context);
context.refreshMobileTabs();assert.equal(context.mobileTabsSelect.children.length,3);assert.equal(context.mobileTabsSelect.value,'/hello.php');assert.equal(context.mobileTabsSelect.children[2].textContent,'● <script>.txt');
context.editorTabs.delete('/hello.php');context.activeEditorPath=null;context.refreshMobileTabs();assert.equal(context.mobileTabsSelect.children.length,2);assert.equal(context.mobileTabsSelect.value,'');
console.log('PASS: mobile wrap/minimap defaults, independent desktop/mobile preferences, open-file selection, dirty names rendered as text, closed-tab refresh.');

assert(source.includes('.editor-panel {position: absolute;inset: 0;width: 100%;height: 100%;'));
assert(source.includes('#fontSize, #indentation {display: block;}'));
assert(source.includes("setProperty('--mobile-viewport-height', '100%')"));
assert(!source.includes('> .status-item, #fontSize, #indentation {display: none'));
