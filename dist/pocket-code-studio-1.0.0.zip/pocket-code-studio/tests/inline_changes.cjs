const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../filemanager.php'),'utf8');
let resolveLoad,loads=0,created=0,detached=0,baseline,actual='initial',saved='initial',fail=false;
const alerts=[],restored=[],drawErrors=[];
const editor={getValue:()=>actual,getOptions:()=>({animatedScroll:false}),setOptions(){},resize(){},
 selection:{toJSON:()=>({row:3}),fromJSON:v=>restored.push(v)},session:{getLength:()=>actual.split('\n').length,getScrollTop:()=>20,getScrollLeft:()=>4,setScrollTop(){},setScrollLeft(){},getMode:()=>({$id:'ace/mode/text'}),on(){}}};
const window={parent:null,frameElement:null,document:{querySelectorAll:()=>[]},loadInlineDiff:()=>{loads++;return new Promise(resolve=>resolveLoad=resolve);},workspaceAlert:m=>alerts.push(m)};window.parent=window;
const context=vm.createContext({window,editor,document:{addEventListener(){}},localStorage:{getItem:()=>null},TextEncoder,console:{error:(...args)=>drawErrors.push(args)},savedEditorValue:saved,scheduleMinimap(){},
 ace:{require:()=>({createDiffView:model=>{created++;baseline=model.valueA;return {sessionA:{setMode(){},setValue:v=>{if(fail)throw Error('drawing failed');baseline=v;},destroy(){}},detach:()=>detached++};}})}});
const start=source.indexOf('        // Inline comparison uses');vm.runInContext(source.slice(start,source.indexOf('        // ── Verified save',start)),context);
(async()=>{
 const pending=window.setInlineChanges(true);assert.equal(loads,1);await window.setInlineChanges(false);resolveLoad();await pending;assert.equal(created,0,'late module must not enable a cancelled request');
 actual='initial\nnew';const next=window.setInlineChanges(true);resolveLoad();await next;assert.equal(baseline,'initial','compare with saved text even when enabled after editing');
 context.savedEditorValue='initial\nnew';context.refreshInlineChangesBaseline();assert.equal(baseline,'initial\nnew');
 actual+='\nnew edits during save';assert.notEqual(actual,baseline,'only submitted text becomes the new baseline');
 fail=true;context.refreshInlineChangesBaseline();fail=false;assert.equal(drawErrors.length,1);assert.equal(baseline,'initial\nnew');
 await window.setInlineChanges(false);assert.equal(detached,1);assert.equal(restored[0].row,3);assert.equal(window.inlineChangesEnabled,false);
 actual='x'.repeat(1024*1024+1);await window.setInlineChanges(true);assert.equal(alerts.length,1);assert.equal(window.inlineChangesEnabled,false);
 assert(source.indexOf('refreshInlineChangesBaseline();',source.indexOf('async function saveFile()'))>source.indexOf('fileRevision = result.hash;',source.indexOf('async function saveFile()')));
 console.log('PASS: lazy inline changes, cancellation, verified-save baseline, concurrent edits, draw failure isolation and size guard.');
})().catch(e=>{console.error(e);process.exitCode=1;});
