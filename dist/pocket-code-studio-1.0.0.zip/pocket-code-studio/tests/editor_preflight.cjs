const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../filemanager.php'),'utf8');
const pending=[],tabs=new Map(),created=[],alerts=[],activated=[];
const context=vm.createContext({SERVER_ROOT_PATH:'/site',currentPath:'',editorTabs:tabs,window:{location:{pathname:'/filemanager.php'},workspaceAlert:message=>alerts.push(message)},
    fetch:url=>new Promise(resolve=>pending.push({url,resolve})),activateTab:path=>activated.push(path),
    createEditorTab:(name,dir,point,active)=>{created.push({name,active});tabs.set('/site'+dir+'/'+name,{});}});
const start=source.indexOf('            function editorFilePath('),end=source.indexOf('            function createEditorTab(',start);
vm.runInContext('let openRequestSerial=0;const pendingEditorOpens=new Map();\n'+source.slice(start,end),context);
(async()=>{
    const bad=context.openFileEditor('binary.dat');
    assert.equal(created.length,0);assert.equal(activated.length,0);
    pending[0].resolve({ok:false,json:async()=>({status:'error',message:'Unsupported encoding'})});await bad;
    assert.equal(created.length,0);assert.equal(activated.length,0);assert.equal(alerts[0],'Unsupported encoding');
    const first=context.openFileEditor('index.php','/a');
    const duplicate=context.openFileEditor('index.php','/a');assert.equal(first,duplicate);assert.equal(pending.length,2);
    const second=context.openFileEditor('index.php','/b');
    pending[1].resolve({ok:true,json:async()=>({status:'success',kind:'text'})});await first;
    assert.equal(created[0].active,false);
    pending[2].resolve({ok:true,json:async()=>({status:'success',kind:'text'})});await second;
    assert.equal(created[1].active,true);
    await context.openFileEditor('index.php','/a');assert.equal(activated[0],'/site/a/index.php');
    const restored=context.openFileEditor('image.png','',null,false);
    pending[3].resolve({ok:true,json:async()=>({status:'success',kind:'image'})});await restored;
    assert.equal(created[2].active,false);
    console.log('PASS: unsupported files create no tab or navigation, duplicate opens deduplicated, late results do not steal focus, background restore.');
})().catch(error=>{console.error(error);process.exitCode=1;});
