const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
const handlers = {}, anchors = [], decorations = new Set(), jumps = [], frames = [];
const rail = {hidden:true, get clientHeight(){return this.hidden ? 0 : 208;}, children:[], replaceChildren(){this.children=[];}, append(x){this.children.push(x);}};
const editor = {on:(name,fn)=>handlers[name]=fn, focus(){}, gotoLine:line=>jumps.push(line),
 renderer:{$gutterLayer:{getRegion:event=>event.region}}, session:{
 on(){}, getLength:()=>101, removeGutterDecoration:row=>decorations.delete(row), addGutterDecoration:row=>decorations.add(row),
 addMarker:()=>1,removeMarker(){},doc:{createAnchor(row){const anchor={row,on(name,fn){this.changed=fn;},detach(){this.detached=true;}};anchors.push(anchor);return anchor;}}
}};
const context = {editor, document:{getElementById:()=>rail,createElement:()=>({style:{},setAttribute(){},addEventListener(name,fn){this[name]=fn;}})},
 requestAnimationFrame:fn=>{frames.push(fn);return frames.length;},ResizeObserver:class{observe(){}},setTimeout:()=>1,clearTimeout(){},ace:{require:()=>({Range:class{}})}};
const start=source.indexOf('        // Temporary bookmarks');
vm.runInNewContext(source.slice(start,source.indexOf("        // Remove Ace's default border",start)),context);
function flush(){while(frames.length)frames.shift()();}
function click(row,region){let stopped=false;handlers.guttermousedown({region,getButton:()=>0,domEvent:{target:{classList:{contains:()=>true}}},getDocumentPosition:()=>({row}),stop(){stopped=true;}});flush();return stopped;}
assert.equal(click(10,'foldWidgets'),false);assert.equal(rail.children.length,0);
assert.equal(click(10),true);assert(decorations.has(10));assert.equal(rail.children[0].style.top,'20px');
rail.children[0].click();assert.deepEqual(jumps,[11]);
anchors[0].row=30;anchors[0].changed();flush();assert(!decorations.has(10));assert(decorations.has(30));assert.equal(rail.children[0].style.top,'60px');
click(50);assert.equal(rail.children.length,2);assert.deepEqual(rail.children.map(tick=>tick.style.top),['60px','100px'],'each bookmark must have its own position while rebuilding the rail');anchors[1].row=30;anchors[1].changed();flush();assert.equal(rail.children.length,1,'deletions merging bookmarked lines must deduplicate');
click(30);assert.equal(rail.children.length,0);assert.equal(decorations.size,0);assert.equal(rail.hidden,true);
assert(source.includes('#bookmark-rail[hidden] {display: none;}'));
assert(!source.includes('#bookmark-rail:empty'));
assert(!source.slice(start,source.indexOf("        // Remove Ace's default border",start)).includes('localStorage'));
console.log('PASS: temporary bookmarks, gutter guards, navigation, anchor movement, merged lines and removal.');
