const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
let handler; const calls = [];
const menu = {addEventListener: (type, fn) => handler = fn};
const context = vm.createContext({contextTarget: {name: 'photo.png', type: 'file', directory: '/images'},
    workspaceRoot: '/srv/site', currentPath: '/other', selectedItems: [], fileList: [], editorTabs: new Map(),
    document: {getElementById: id => id === 'context-menu' ? menu : {click: () => calls.push(id)}, querySelectorAll: () => []},
    window: {location: {pathname: '/filemanager.php'}}, hideContextMenu() {}, tabHasChanges: tab => !!tab?.dirty,
    activateTab: path => calls.push(['activate', path]), navigateTo: path => calls.push(['navigate', path]),
    openFileEditor: (...args) => calls.push(['open', ...args]), updateButtonStates() {},
    loadFileList: async () => { context.fileList = [{name: 'photo.png'}]; }, showAlert: (...args) => calls.push(['alert', ...args])});
const start = source.indexOf('            const contextActions = {');
const end = source.indexOf('            // ── HTMX hooks', start);
vm.runInContext(source.slice(start, end), context);
const click = id => handler({target: {closest: () => ({id})}});
(async () => {
    await click('ctx-edit');
    assert.deepEqual(calls.pop(), ['open', 'photo.png', '/images']);
    await click('ctx-copy');
    assert.equal(context.currentPath, '/images');
    assert.deepEqual(Array.from(context.selectedItems), ['photo.png']);
    assert.equal(calls.pop(), 'copy-btn');
    context.editorTabs.set('/srv/site/images/photo.png', {dirty: true});
    await click('ctx-delete');
    assert.equal(calls.at(-1)[0], 'alert');
    assert.equal(calls.includes('delete-btn'), false);
    context.editorTabs.clear();
    context.loadFileList = async () => { context.currentPath = '/elsewhere'; };
    await click('ctx-rename');
    assert.equal(calls.includes('rename-btn'), false);
    await click('ctx-download');
    assert.match(context.window.location.href, /path=%2Fimages&file=photo.png$/);
    console.log('PASS: sidebar directory targeting, file selection, dirty guards, navigation races, image opening/download.');
})().catch(error => {console.error(error); process.exitCode = 1;});
