// Exercise the actual list loader with responses arriving out of order.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../filemanager.php'), 'utf8');
const start = source.indexOf('            async function requestWorkspace(');
const end = source.indexOf('            const fileMimeTypes', start);
const pending = [], displayed = [], alerts = [];
const tbody = {innerHTML: '', replaceChildren() { this.failed = true; }};
const breadcrumb = {};
const context = vm.createContext({FormData, AbortController,
    window: {location: {pathname: '/filemanager.php'}},
    document: {getElementById: id => id === 'files-list' ? tbody : breadcrumb,
        createElement: () => ({style: {}, append() {}})},
    fetch: (url, options) => new Promise(resolve => pending.push({resolve, options})),
    refreshGitStatus() {}, updateButtonStates() {},
    showFiles: files => displayed.push(files), showAlert: (...args) => alerts.push(args)
});
vm.runInContext("let currentPath='/first', selectedItems=[], fileList=[], currentSort='name', currentOrder='asc';\n" + source.slice(start, end), context);
(async () => {
    const first = vm.runInContext('loadFileList()', context);
    vm.runInContext("currentPath='/second'", context);
    const second = vm.runInContext('loadFileList()', context);
    assert.equal(pending[0].options.signal.aborted, true);
    pending[1].resolve({ok: true, json: async () => ({status: 'success', current_path: '/second', data: ['new']})});
    await second;
    pending[0].resolve({ok: true, json: async () => ({status: 'success', current_path: '/first', data: ['old']})});
    await first;
    assert.deepEqual(displayed, [['new']]);
    assert.equal(breadcrumb.value, '/second');
    const failure = vm.runInContext('loadFileList()', context);
    pending[2].resolve({ok: false, json: async () => ({status: 'error', message: 'Cannot read folder'})});
    await failure;
    assert.equal(tbody.failed, true);
    assert.equal(alerts[0][1], 'Cannot read folder');
    const malformed = vm.runInContext('loadFileList()', context);
    pending[3].resolve({ok: false, status: 502, json: async () => { throw new SyntaxError('HTML response'); }});
    await malformed;
    assert.match(alerts[1][1], /invalid response.*HTTP 502/);
    const form = new FormData(); form.set('items', 'file.txt'); context.operationForm = form;
    const operation = vm.runInContext("requestWorkspace('copy', operationForm)", context);
    assert.equal(pending[4].options.body.get('items'), 'file.txt');
    assert.equal(pending[4].options.body.get('action'), 'copy');
    pending[4].resolve({ok: true, json: async () => ({status: 'success'})});
    await operation;
    console.log('PASS: stale responses, cancellation, server/JSON errors and FormData operations.');
})().catch(error => { console.error(error); process.exitCode = 1; });
