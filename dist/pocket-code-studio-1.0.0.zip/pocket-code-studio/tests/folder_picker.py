"""Folder browsing and workspace switching operate on temporary fixtures only."""
import base64,json,re,socket,subprocess,tempfile,time,urllib.parse
from pathlib import Path
helpers=Path(__file__).with_name('authentication.py').read_text().split("with tempfile.TemporaryDirectory(prefix='fm-auth-tests-')")[0]
namespace={'__file__':str(Path(__file__).with_name('authentication.py'))};exec(helpers,namespace)
Client=namespace['Client'];PASSWORD=namespace['PASSWORD'];SOURCE=namespace['SOURCE'];test_hash=namespace['test_hash']
with tempfile.TemporaryDirectory(prefix='pcs-folders-') as temporary:
    base=Path(temporary).resolve(); web=base/'website'; sibling=base/'other-site';web.mkdir();sibling.mkdir()
    dest=web/'folder space';dest.mkdir();(web/'file.txt').write_text('example')
    (sibling/'outside.txt').write_text('outside')
    (web/'escape').symlink_to(sibling,target_is_directory=True)
    target=web/'filemanager.php'
    target.write_text(re.sub(r"^\$authPasswordHash = '[^']*';$","$authPasswordHash = '"+test_hash(PASSWORD)+"';",SOURCE.read_text(),flags=re.M))
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    server=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(web)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        client=Client(f'http://127.0.0.1:{port}/filemanager.php')
        for _ in range(100):
            try:client.request();break
            except OSError:time.sleep(.03)
        assert client.request(fields={'action':'browse_folders','scope':'server','folder':str(base)})[0]==403
        status,body,_=client.login();assert status==200
        client.csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',body)[1].decode()
        def browse(scope,folder):
            status,body,_=client.request(fields={'action':'browse_folders','scope':scope,'folder':folder});return status,json.loads(body)
        status,data=browse('workspace','/');assert status==200 and data['parent'] is None
        assert {i['name'] for i in data['folders']}=={'folder space'}
        assert browse('workspace','/escape')[0]==403
        assert browse('workspace','/../other-site')[0]==403
        assert browse('server',str(base))[0]==200
        status,data=browse('server',str(sibling));assert status==200 and data['folder']==str(sibling)
        assert browse('server',str(base/'missing'))[0]==403
        assert browse('invalid','/')[0]==400
        status,body,_=client.request(fields={'action':'move','path':'','items':'file.txt','destination':'/folder space'})
        assert json.loads(body)['status']=='success',body
        assert (dest/'file.txt').read_text()=='example' and not (web/'file.txt').exists()
        settings={'fm_auth_action':'save_settings','timezone':'UTC','dateformat':'M j Y, H:i:s','fontSize':'16px','workspace_root':str(base)}
        before=target.read_bytes()
        assert client.request(fields={**settings,'workspace_root':str(base/'missing')})[0]==400
        assert target.read_bytes()==before
        status,body,_=client.request(fields=settings);assert status==200,body
        status,body,_=client.request();assert status==200 and b'id="settings-root"' in body
        assert json.loads(re.search(rb'var SERVER_ROOT_PATH = (.*?);',body)[1])==str(base)
        status,listing,_=client.request(fields={'action':'list','path':'/other-site'})
        assert 'outside.txt' in [i['name'] for i in json.loads(listing)['data']]
        q='?editor=1&filename='+urllib.parse.quote(str(sibling/'outside.txt'),safe='')
        assert b'const originalContent = "outside"' in client.request(q)[1]
        # Legacy settings updates must preserve the workspace root.
        client.request(fields={'action':'settings','timezone':'UTC','dateformat':'Y-m-d','fontSize':'18px'})
        stored=json.loads(base64.b64decode(re.search(r"^\$workspaceSettingsBase64 = '([^']*)';$",target.read_text(),re.M)[1]))
        assert stored['root_path']==str(base)
        print('PASS: authenticated folder browsing, workspace containment/symlinks, folder destination move, validated root switch, outside-site editing and root persistence.')
    finally:server.terminate();server.wait()
