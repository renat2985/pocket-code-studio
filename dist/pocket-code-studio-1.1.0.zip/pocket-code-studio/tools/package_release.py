"""Create a publication archive from an explicit, credential-free allowlist."""
from pathlib import Path
import re, zipfile, subprocess
root=Path(__file__).resolve().parents[1]
source=(root/'filemanager.php').read_text()
match = re.search(r"^\$authPasswordHash = '([^']*)';\s*$", source, re.M)
if not match:
    raise SystemExit('Cannot locate the password hash.')
check = subprocess.run(['php','-r','exit(password_verify("admin123", trim(stream_get_contents(STDIN))) ? 0 : 1);'], input=match[1], text=True)
if check.returncode:
    raise SystemExit('Refusing to package a personal deployment password. Expected the documented default admin123.')
paths=[root/name for name in ['filemanager.php','README.md','README.ru.md','LICENSE','CREDITS.md','THIRD_PARTY_NOTICES.md','.gitignore']]
for directory in ['docs','tests','tools','screenshots']:
    paths.extend(p for p in (root/directory).rglob('*') if p.is_file() and p.name != '.DS_Store' and '__pycache__' not in p.parts and p.suffix!='.pyc')
version = re.search(r'Pocket Code Studio v([0-9]+\.[0-9]+\.[0-9]+)', source)
if not version: raise SystemExit('Cannot locate the release version.')
output=root/'dist'/('pocket-code-studio-'+version[1]+'.zip');output.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(paths):archive.write(path,'pocket-code-studio/'+path.relative_to(root).as_posix())
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert archive.read('pocket-code-studio/filemanager.php').decode()==source
print(f'{output}\n{len(paths)} files; {output.stat().st_size:,} bytes; archive verified')
