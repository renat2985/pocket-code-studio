"""HTTP update checks against a disposable, renamed editor; never writes the working source."""
import base64,hashlib,http.cookiejar,json,re,shutil,socket,subprocess,tempfile,time,urllib.request,urllib.error,urllib.parse
from pathlib import Path
source=Path(__file__).resolve().parents[1].joinpath('filemanager.php').read_text()
current_version=re.search(r'Pocket Code Studio v([0-9]+\.[0-9]+\.[0-9]+)',source)[1]
next_version='.'.join(current_version.split('.')[:2]+[str(int(current_version.split('.')[2])+1)])
with tempfile.TemporaryDirectory(prefix='fm-self-update-') as folder:
 root=Path(folder); target=root/'private-tools-827.php'
 password='Update-test-password'
 hashed=subprocess.check_output(['php','-r','echo password_hash($argv[1], PASSWORD_BCRYPT, ["cost"=>4]);',password]).decode()
 source=re.sub(r"^\$authPasswordHash = '[^']*';$",lambda _:"$authPasswordHash = '"+hashed+"';",source,flags=re.M)
 settings=base64.b64encode(json.dumps({'root_path':str(root),'timezone':'UTC','date_format':'Y-m-d','font_size':'12px'}).encode()).decode()
 source=source.replace("$workspaceSettingsBase64 = '';","$workspaceSettingsBase64 = '"+settings+"';",1)
 target.write_text(source);target.chmod(0o640)
 private=Path(subprocess.check_output(['php','-r','echo sys_get_temp_dir();']).decode())/('fm-auth-'+hashlib.sha256(str(target.resolve()).encode()).hexdigest()[:24])
 client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 url=f'http://127.0.0.1:{port}/{target.name}'
 process=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 def fetch(data=None,headers=None):
  try:
   with client.open(urllib.request.Request(url,data=data,headers=headers or {}),timeout=10) as response:return response.status,response.read()
  except urllib.error.HTTPError as error:return error.code,error.read()
 def post(operation,token='',candidate=None,csrf_override=None):
  fields={'action':'editor_update','operation':operation,'token':token}
  if candidate is None:
   payload=urllib.parse.urlencode(fields).encode();headers={'Content-Type':'application/x-www-form-urlencoded'}
  else:
   boundary='----PocketUpdateTest';chunks=[]
   for name,value in fields.items():chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
   chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="release"; filename="filemanager.php"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+candidate+f'\r\n--{boundary}--\r\n'.encode())
   payload=b''.join(chunks);headers={'Content-Type':'multipart/form-data; boundary='+boundary}
  headers['X-FM-CSRF']=csrf if csrf_override is None else csrf_override
  status,body=fetch(payload,headers);return status,json.loads(body)
 try:
  for _ in range(100):
   try:status,html=fetch();break
   except OSError:time.sleep(.03)
  csrf=re.search(rb'name="fm_csrf" value="([a-f0-9]+)"',html)[1].decode()
  status,html=fetch(urllib.parse.urlencode({'fm_auth_action':'login','password':password,'fm_csrf':csrf}).encode(),{'Content-Type':'application/x-www-form-urlencoded'})
  csrf=re.search(rb'const fmCSRF = "([a-f0-9]+)";',html)[1].decode()
  candidate=source.replace(hashed,'RELEASE-DEFAULT-HASH',1).replace("$workspaceSettingsBase64 = '"+settings+"';","$workspaceSettingsBase64 = '';",1).replace('Pocket Code Studio v'+current_version,'Pocket Code Studio v'+next_version,1).encode()
  assert post('preview',candidate=candidate,csrf_override='wrong')[0]==403
  assert post('install',token='wrong')[0]==400
  assert post('preview',candidate=b'<?php echo "wrong";')[0]==400
  assert post('preview',candidate=candidate+b'<?php broken syntax = ;')[0]==400
  assert post('preview',candidate=candidate.replace(b'Minimum PHP: 7.4',b'Minimum PHP: 99.0'))[0]==400
  status,data=post('preview',candidate=candidate);assert status==200,data
  assert data['filename']==target.name and data['version']==next_version
  assert target.read_text()==source,'preview must not replace live file'
  target.write_text(source+'\n<!-- concurrent change -->')
  assert post('install',token=data['token'])[0]==400,'reject changed installation after review'
  target.write_text(source)
  status,data=post('preview',candidate=candidate);assert status==200,data
  status,result=post('install',token=data['token']);assert status==200,result
  updated=target.read_text();assert 'Pocket Code Studio v'+next_version in updated
  assert "$authPasswordHash = '"+hashed+"';" in updated
  assert "$workspaceSettingsBase64 = '"+settings+"';" in updated
  assert target.stat().st_mode & 0o777==0o640
  backups=list(private.glob('configuration-*.bak'));assert any(p.read_text()==source for p in backups)
  assert not list(private.glob('update-*.php'))
  assert not (root/'filemanager.php').exists(),'keep renamed installation'
  assert fetch()[0]==200,'session survives preserved password'
  print('PASS: renamed self-update, CSRF, invalid/unsupported releases, preview, concurrent edits, password/settings/mode preservation, backup and stage cleanup.')
 finally:
  process.terminate();process.wait(timeout=5)
  if private.is_dir():shutil.rmtree(private)
